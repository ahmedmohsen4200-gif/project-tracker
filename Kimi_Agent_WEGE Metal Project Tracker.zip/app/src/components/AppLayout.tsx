import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router";
import { useAuth } from "@/hooks/useAuth";
import { trpc } from "@/providers/trpc";
import {
  LayoutDashboard, FolderKanban, FileCheck, FileText,
  Package, Truck, HardHat, Receipt, BarChart3,
  Settings, Users, Bell, ChevronLeft, ChevronRight,
  LogOut, Building2, Activity
} from "lucide-react";
import { Button } from "@/components/ui/button";

const navItems = [
  { label: "Dashboard", path: "/", icon: LayoutDashboard },
  { label: "Projects", path: "/projects", icon: FolderKanban },
  { label: "Submittals", path: "/submittals", icon: FileCheck },
  { label: "Shop Drawings", path: "/drawings", icon: FileText },
  { label: "Quantities", path: "/quantities", icon: Package },
  { label: "Deliveries", path: "/deliveries", icon: Truck },
  { label: "Installation", path: "/installation", icon: HardHat },
  { label: "Payments", path: "/payments", icon: Receipt },
  { label: "Reports", path: "/reports", icon: BarChart3 },
  { label: "Activity Log", path: "/activity", icon: Activity },
  { label: "Team", path: "/users", icon: Users },
  { label: "Settings", path: "/settings", icon: Settings },
];

export default function AppLayout({ children }: { children: React.ReactNode }) {
  const [collapsed, setCollapsed] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [companyId] = useState(() => {
    const stored = localStorage.getItem("pl_company_id");
    return stored ? parseInt(stored) : undefined;
  });
  const { data: company } = trpc.companies.getById.useQuery(
    { id: companyId! },
    { enabled: !!companyId }
  );
  const { data: unreadCount } = trpc.notifications.unreadCount.useQuery(
    { companyId: companyId! },
    { enabled: !!companyId, refetchInterval: 30000 }
  );

  return (
    <div className="flex h-screen w-full bg-[#050505] text-white overflow-hidden">
      {/* Sidebar */}
      <aside
        className={`flex flex-col border-r border-white/5 bg-[#0A0A0A] transition-all duration-300 ${
          collapsed ? "w-16" : "w-60"
        }`}
      >
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 h-16 border-b border-white/5">
          <Link to="/" className="flex items-center gap-3 min-w-0">
            <img src="/logo.png" alt="Project Line" className="h-8 w-8 flex-shrink-0" />
            {!collapsed && (
              <span className="font-semibold text-sm tracking-tight truncate">
                Project Line
              </span>
            )}
          </Link>
        </div>

        {/* Company selector */}
        {!collapsed && (
          <div className="px-3 py-2 border-b border-white/5">
            <div className="text-xs text-muted-foreground px-3 py-1">WORKSPACE</div>
            <button
              onClick={() => navigate("/settings")}
              className="flex items-center gap-2 w-full px-3 py-2 rounded-lg hover:bg-white/5 transition-colors text-left"
            >
              <Building2 className="w-4 h-4 text-amber-500" />
              <span className="text-sm truncate">{company?.name || "Select Company"}</span>
            </button>
          </div>
        )}

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {navItems.map((item) => {
            const isActive =
              item.path === "/" ? location.pathname === "/" : location.pathname.startsWith(item.path);
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2 rounded-lg transition-all duration-200 group ${
                  isActive
                    ? "bg-amber-500/10 text-amber-500 border border-amber-500/20"
                    : "text-muted-foreground hover:text-white hover:bg-white/5"
                } ${collapsed ? "justify-center" : ""}`}
                title={collapsed ? item.label : undefined}
              >
                <item.icon className={`w-[18px] h-[18px] flex-shrink-0 ${isActive ? "text-amber-500" : ""}`} />
                {!collapsed && <span className="text-sm">{item.label}</span>}
              </Link>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="border-t border-white/5 p-2">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="flex items-center gap-3 px-3 py-2 rounded-lg text-muted-foreground hover:text-white hover:bg-white/5 transition-colors w-full"
          >
            {collapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <>
                <ChevronLeft className="w-4 h-4" />
                <span className="text-sm">Collapse</span>
              </>
            )}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex flex-col flex-1 min-w-0">
        {/* Header */}
        <header className="h-16 border-b border-white/5 bg-[#0A0A0A]/80 backdrop-blur-xl flex items-center justify-between px-6 flex-shrink-0">
          <div className="flex items-center gap-4">
            <h1 className="text-sm font-medium text-muted-foreground">
              {navItems.find((i) =>
                i.path === "/" ? location.pathname === "/" : location.pathname.startsWith(i.path)
              )?.label || "Project Line"}
            </h1>
          </div>
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate("/notifications")}
              className="relative p-2 rounded-lg hover:bg-white/5 transition-colors"
            >
              <Bell className="w-[18px] h-[18px] text-muted-foreground" />
              {!!unreadCount && unreadCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-amber-500 rounded-full text-[10px] font-bold flex items-center justify-center text-white">
                  {unreadCount}
                </span>
              )}
            </button>
            <div className="flex items-center gap-3">
              {user?.avatar ? (
                <img src={user.avatar} className="w-8 h-8 rounded-full ring-1 ring-white/10" alt="" />
              ) : (
                <div className="w-8 h-8 rounded-full bg-amber-500/20 flex items-center justify-center ring-1 ring-amber-500/30">
                  <span className="text-xs font-medium text-amber-500">
                    {(user?.name || "U").charAt(0).toUpperCase()}
                  </span>
                </div>
              )}
              <div className="hidden md:block">
                <div className="text-sm font-medium leading-tight">{user?.name || "User"}</div>
                <div className="text-xs text-muted-foreground">{user?.email}</div>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={logout}
                className="text-muted-foreground hover:text-white"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
