import { useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Plus, Pencil, Trash2, Search, Receipt } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const PAYMENT_STATUS = ["submitted", "under_review", "approved", "partially_paid", "paid", "rejected"];
const STATUS_COLORS: Record<string, string> = { submitted: "#F59E0B", under_review: "#3B82F6", approved: "#22C55E", partially_paid: "#F97316", paid: "#10B981", rejected: "#EF4444" };

export default function PaymentsPage() {
  const [searchParams] = useSearchParams();
  const projectIdParam = searchParams.get("project");
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data } = trpc.payments.list.useQuery({ companyId, projectId: projectIdParam ? parseInt(projectIdParam) : undefined });
  const createMut = trpc.payments.create.useMutation({ onSuccess: () => { utils.payments.list.invalidate(); setIsOpen(false); } });
  const updateMut = trpc.payments.update.useMutation({ onSuccess: () => { utils.payments.list.invalidate(); setEditId(null); } });
  const deleteMut = trpc.payments.delete.useMutation({ onSuccess: () => utils.payments.list.invalidate() });
  const projects = trpc.projects.list.useQuery({ companyId });
  const projectMap = useMemo(() => { const m: Record<number, string> = {}; (projects.data || []).forEach(p => m[p.id] = p.name); return m; }, [projects.data]);
  const filtered = useMemo(() => !data ? [] : search ? data.filter(p => p.certificateNumber.toLowerCase().includes(search.toLowerCase())) : data, [data, search]);
  const editing = editId ? data?.find(p => p.id === editId) : null;

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      projectId: parseInt(fd.get("projectId") as string), companyId,
      certificateNumber: fd.get("certificateNumber"),
      submittedAmount: fd.get("submittedAmount") || undefined,
      submissionDate: fd.get("submissionDate") || undefined,
      approvedAmount: fd.get("approvedAmount") || undefined,
      approvalDate: fd.get("approvalDate") || undefined,
      receivedAmount: fd.get("receivedAmount") || undefined,
      paymentReceivedDate: fd.get("paymentReceivedDate") || undefined,
      pendingAmount: fd.get("pendingAmount") || undefined,
      retentionAmount: fd.get("retentionAmount") || undefined,
      vatAmount: fd.get("vatAmount") || undefined,
      totalCollected: fd.get("totalCollected") || undefined,
      remainingBalance: fd.get("remainingBalance") || undefined,
      paymentStatus: fd.get("paymentStatus") || "submitted",
      notes: fd.get("notes") || undefined,
    };
    if (editId) { payload.id = editId; delete payload.projectId; delete payload.companyId; updateMut.mutate(payload); }
    else createMut.mutate(payload);
  };

  const formatCurrency = (val: string | null) => {
    const num = parseFloat(val || "0");
    return isNaN(num) ? "$0.00" : `$${num.toLocaleString("en-US", { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Payment Certificates</h2><p className="text-sm text-muted-foreground">Track invoices, approvals, and collections</p></div>
        <Dialog open={isOpen} onOpenChange={(v) => { setIsOpen(v); setEditId(null); }}>
          <DialogTrigger asChild><Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2"><Plus className="w-4 h-4" /> Add Certificate</Button></DialogTrigger>
          <DialogContent className="max-w-xl bg-[#0F0F0F] border-white/10 max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{editId ? "Edit" : "Add"} Payment Certificate</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-2"><Label>Project</Label><Select name="projectId" defaultValue={projectIdParam || editing?.projectId?.toString()}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{(projects.data || []).map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Certificate # *</Label><Input name="certificateNumber" defaultValue={editing?.certificateNumber} required className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Status</Label><Select name="paymentStatus" defaultValue={editing?.paymentStatus || "submitted"}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{PAYMENT_STATUS.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Submitted Amount</Label><Input name="submittedAmount" type="number" step="0.01" defaultValue={editing?.submittedAmount || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Submission Date</Label><Input name="submissionDate" type="date" defaultValue={editing?.submissionDate ? new Date(editing.submissionDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Approved Amount</Label><Input name="approvedAmount" type="number" step="0.01" defaultValue={editing?.approvedAmount || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Approval Date</Label><Input name="approvalDate" type="date" defaultValue={editing?.approvalDate ? new Date(editing.approvalDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Received Amount</Label><Input name="receivedAmount" type="number" step="0.01" defaultValue={editing?.receivedAmount || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Payment Date</Label><Input name="paymentReceivedDate" type="date" defaultValue={editing?.paymentReceivedDate ? new Date(editing.paymentReceivedDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2"><Label>Pending</Label><Input name="pendingAmount" type="number" step="0.01" defaultValue={editing?.pendingAmount || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Retention</Label><Input name="retentionAmount" type="number" step="0.01" defaultValue={editing?.retentionAmount || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>VAT</Label><Input name="vatAmount" type="number" step="0.01" defaultValue={editing?.vatAmount || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="space-y-2"><Label>Notes</Label><Textarea name="notes" defaultValue={editing?.notes || ""} className="bg-white/5 border-white/10" /></div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white">{editId ? "Save" : "Create"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="relative max-w-xs"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><Input placeholder="Search certificates..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10" /></div>
      <div className="space-y-3">
        {filtered.map(p => (
          <div key={p.id} className="glass-card p-5 hover:bg-white/[0.04] transition-colors">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center"><Receipt className="w-5 h-5 text-amber-500" /></div>
                <div>
                  <div className="font-medium">{p.certificateNumber}</div>
                  <div className="text-xs text-muted-foreground">{projectMap[p.projectId] || "—"}</div>
                </div>
              </div>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-medium" style={{ background: `${STATUS_COLORS[p.paymentStatus]}20`, color: STATUS_COLORS[p.paymentStatus] }}>{p.paymentStatus.replace(/_/g, " ")}</span>
            </div>
            <div className="grid grid-cols-4 gap-4 mt-4 pt-4 border-t border-white/5">
              <div><div className="text-[10px] text-muted-foreground uppercase tracking-wider">Submitted</div><div className="text-sm font-mono-metrics font-medium">{formatCurrency(p.submittedAmount)}</div></div>
              <div><div className="text-[10px] text-muted-foreground uppercase tracking-wider">Approved</div><div className="text-sm font-mono-metrics font-medium">{formatCurrency(p.approvedAmount)}</div></div>
              <div><div className="text-[10px] text-muted-foreground uppercase tracking-wider">Received</div><div className="text-sm font-mono-metrics font-medium text-emerald-500">{formatCurrency(p.receivedAmount)}</div></div>
              <div><div className="text-[10px] text-muted-foreground uppercase tracking-wider">Pending</div><div className="text-sm font-mono-metrics font-medium text-amber-500">{formatCurrency(p.pendingAmount)}</div></div>
            </div>
            <div className="flex justify-end gap-1 mt-3 pt-3 border-t border-white/5"><Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditId(p.id); setIsOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button><Button variant="ghost" size="icon" className="h-7 w-7 text-red-400" onClick={() => { if (confirm("Delete?")) deleteMut.mutate({ id: p.id }); }}><Trash2 className="w-3.5 h-3.5" /></Button></div>
          </div>
        ))}
        {filtered.length === 0 && <div className="text-center py-12 text-muted-foreground">No payment certificates found</div>}
      </div>
    </div>
  );
}
