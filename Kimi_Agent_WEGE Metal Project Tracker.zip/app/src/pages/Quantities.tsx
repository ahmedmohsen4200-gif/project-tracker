import { useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const ITEM_CATEGORIES = ["curtain_wall", "windows", "doors", "louvers", "cladding", "handrail", "steel_works", "stainless_steel", "glass_works", "skylight", "partitions", "other"];

export default function QuantitiesPage() {
  const [searchParams] = useSearchParams();
  const projectIdParam = searchParams.get("project");
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data } = trpc.items.list.useQuery({ companyId, projectId: projectIdParam ? parseInt(projectIdParam) : undefined });
  const createMut = trpc.items.create.useMutation({ onSuccess: () => { utils.items.list.invalidate(); setIsOpen(false); } });
  const updateMut = trpc.items.update.useMutation({ onSuccess: () => { utils.items.list.invalidate(); setEditId(null); } });
  const deleteMut = trpc.items.delete.useMutation({ onSuccess: () => utils.items.list.invalidate() });
  const projects = trpc.projects.list.useQuery({ companyId });
  const projectMap = useMemo(() => { const m: Record<number, string> = {}; (projects.data || []).forEach(p => m[p.id] = p.name); return m; }, [projects.data]);
  const filtered = useMemo(() => !data ? [] : search ? data.filter(i => i.itemName.toLowerCase().includes(search.toLowerCase())) : data, [data, search]);
  const editing = editId ? data?.find(i => i.id === editId) : null;

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      projectId: parseInt(fd.get("projectId") as string), companyId,
      itemName: fd.get("itemName"), itemCategory: fd.get("itemCategory") || "other",
      unit: fd.get("unit") || "nos", contractQuantity: fd.get("contractQuantity") || "0",
      shopDrawingApprovedQty: fd.get("shopDrawingApprovedQty") || undefined,
      releasedForFabrication: fd.get("releasedForFabrication") || undefined,
      fabricatedQuantity: fd.get("fabricatedQuantity") || undefined,
      deliveredToSite: fd.get("deliveredToSite") || undefined,
      receivedBySite: fd.get("receivedBySite") || undefined,
      installedQuantity: fd.get("installedQuantity") || undefined,
      remainingQuantity: fd.get("remainingQuantity") || undefined,
      notes: fd.get("notes") || undefined,
    };
    if (editId) { payload.id = editId; delete payload.projectId; delete payload.companyId; updateMut.mutate(payload); }
    else createMut.mutate(payload);
  };

  const pct = (num: string | null, den: string | null) => {
    const n = parseFloat(num || "0"), d = parseFloat(den || "0");
    return d > 0 ? Math.round((n / d) * 100) : 0;
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Quantity Tracking</h2><p className="text-sm text-muted-foreground">Track items through all project stages</p></div>
        <Dialog open={isOpen} onOpenChange={(v) => { setIsOpen(v); setEditId(null); }}>
          <DialogTrigger asChild><Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2"><Plus className="w-4 h-4" /> Add Item</Button></DialogTrigger>
          <DialogContent className="max-w-xl bg-[#0F0F0F] border-white/10 max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{editId ? "Edit" : "Add"} Item</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-2"><Label>Project</Label><Select name="projectId" defaultValue={projectIdParam || editing?.projectId?.toString()}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{(projects.data || []).map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Item Name *</Label><Input name="itemName" defaultValue={editing?.itemName} required className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Category</Label><Select name="itemCategory" defaultValue={editing?.itemCategory || "other"}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{ITEM_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c.replace(/_/g, " ")}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Unit</Label><Input name="unit" defaultValue={editing?.unit || "nos"} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Contract Qty</Label><Input name="contractQuantity" type="number" step="0.01" defaultValue={editing?.contractQuantity || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2"><Label>Shop Drawing Qty</Label><Input name="shopDrawingApprovedQty" type="number" step="0.01" defaultValue={editing?.shopDrawingApprovedQty || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Released Fab</Label><Input name="releasedForFabrication" type="number" step="0.01" defaultValue={editing?.releasedForFabrication || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Fabricated</Label><Input name="fabricatedQuantity" type="number" step="0.01" defaultValue={editing?.fabricatedQuantity || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2"><Label>Delivered</Label><Input name="deliveredToSite" type="number" step="0.01" defaultValue={editing?.deliveredToSite || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Received</Label><Input name="receivedBySite" type="number" step="0.01" defaultValue={editing?.receivedBySite || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Installed</Label><Input name="installedQuantity" type="number" step="0.01" defaultValue={editing?.installedQuantity || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white">{editId ? "Save" : "Create"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="relative max-w-xs"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><Input placeholder="Search items..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10" /></div>
      <div className="glass-card overflow-x-auto">
        <table className="w-full text-sm min-w-[900px]">
          <thead className="bg-white/5 text-muted-foreground text-xs uppercase"><tr>
            <th className="text-left p-3">Item</th><th className="text-left p-3">Project</th><th className="text-left p-3">Unit</th>
            <th className="text-right p-3">Contract</th><th className="text-right p-3">Shop Drw</th><th className="text-right p-3">Fabricated</th>
            <th className="text-right p-3">Delivered</th><th className="text-right p-3">Installed</th><th className="text-right p-3">%</th><th className="text-right p-3">Actions</th>
          </tr></thead>
          <tbody className="divide-y divide-white/5">
            {filtered.map(item => {
              const progress = pct(item.installedQuantity, item.contractQuantity);
              return (
                <tr key={item.id} className="hover:bg-white/[0.02]">
                  <td className="p-3 font-medium">{item.itemName}</td>
                  <td className="p-3 text-muted-foreground text-xs">{projectMap[item.projectId] || "—"}</td>
                  <td className="p-3 text-muted-foreground text-xs">{item.unit}</td>
                  <td className="p-3 text-right font-mono-metrics">{item.contractQuantity}</td>
                  <td className="p-3 text-right font-mono-metrics">{item.shopDrawingApprovedQty || "—"}</td>
                  <td className="p-3 text-right font-mono-metrics">{item.fabricatedQuantity || "—"}</td>
                  <td className="p-3 text-right font-mono-metrics">{item.deliveredToSite || "—"}</td>
                  <td className="p-3 text-right font-mono-metrics">{item.installedQuantity || "—"}</td>
                  <td className="p-3 text-right"><div className="flex items-center gap-2 justify-end"><div className="w-12 h-1.5 bg-white/10 rounded-full overflow-hidden"><div className="h-full rounded-full transition-all" style={{ width: `${progress}%`, background: progress >= 100 ? "#22C55E" : progress >= 50 ? "#D97706" : "#EF4444" }} /></div><span className="text-xs font-mono-metrics w-8">{progress}%</span></div></td>
                  <td className="p-3 text-right"><Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditId(item.id); setIsOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button><Button variant="ghost" size="icon" className="h-8 w-8 text-red-400" onClick={() => { if (confirm("Delete?")) deleteMut.mutate({ id: item.id }); }}><Trash2 className="w-3.5 h-3.5" /></Button></td>
                </tr>
              );
            })}
            {filtered.length === 0 && <tr><td colSpan={10} className="p-8 text-center text-muted-foreground">No items found</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
