import { useState } from "react";
import { trpc } from "@/providers/trpc";
import { Building2, Save, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function SettingsPage() {
  const [companyId, setCompanyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const { data: companies } = trpc.companies.list.useQuery();
  const { data: company } = trpc.companies.getById.useQuery({ id: companyId }, { enabled: companyId > 0 });
  const utils = trpc.useUtils();
  const updateMutation = trpc.companies.update.useMutation({ onSuccess: () => utils.companies.getById.invalidate({ id: companyId }) });
  const createMutation = trpc.companies.create.useMutation({
    onSuccess: (data) => {
      utils.companies.list.invalidate();
      if (data?.id) {
        localStorage.setItem("pl_company_id", data.id.toString());
        setCompanyId(data.id);
      }
    },
  });
  const [isCreateOpen, setIsCreateOpen] = useState(false);

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: companyId,
      name: fd.get("name") as string,
      contactEmail: fd.get("contactEmail") as string || undefined,
      contactPhone: fd.get("contactPhone") as string || undefined,
      address: fd.get("address") as string || undefined,
      website: fd.get("website") as string || undefined,
      themeColor: fd.get("themeColor") as string || undefined,
    });
  };

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    createMutation.mutate({
      name: fd.get("name") as string,
      slug: (fd.get("name") as string).toLowerCase().replace(/\s+/g, "-"),
      contactEmail: fd.get("contactEmail") as string || undefined,
    }, {
      onSuccess: () => setIsCreateOpen(false),
    });
  };

  const switchCompany = (id: number) => {
    localStorage.setItem("pl_company_id", id.toString());
    setCompanyId(id);
    window.location.reload();
  };

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div>
        <h2 className="text-xl font-semibold">Settings</h2>
        <p className="text-sm text-muted-foreground mt-0.5">Manage your company workspace and preferences</p>
      </div>

      <Tabs defaultValue="company" className="w-full">
        <TabsList className="bg-white/5 border border-white/10">
          <TabsTrigger value="company" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white"><Building2 className="w-4 h-4 mr-2" /> Company</TabsTrigger>
          <TabsTrigger value="workspaces" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white"><Building2 className="w-4 h-4 mr-2" /> Workspaces</TabsTrigger>
        </TabsList>

        <TabsContent value="company" className="mt-4">
          {company ? (
            <form onSubmit={handleUpdate} className="glass-card p-6 space-y-4">
              <div className="space-y-2"><Label>Company Name</Label><Input name="name" defaultValue={company.name} className="bg-white/5 border-white/10" /></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2"><Label>Contact Email</Label><Input name="contactEmail" type="email" defaultValue={company.contactEmail || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Contact Phone</Label><Input name="contactPhone" defaultValue={company.contactPhone || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="space-y-2"><Label>Address</Label><Textarea name="address" defaultValue={company.address || ""} className="bg-white/5 border-white/10" /></div>
              <div className="space-y-2"><Label>Website</Label><Input name="website" defaultValue={company.website || ""} className="bg-white/5 border-white/10" /></div>
              <div className="space-y-2"><Label>Theme Color</Label>
                <div className="flex gap-2">
                  {["#D97706", "#3B82F6", "#8B5CF6", "#10B981", "#EF4444", "#EC4899"].map(c => (
                    <button key={c} type="button" name="themeColor" value={c} className="w-8 h-8 rounded-full ring-2 ring-offset-2 ring-offset-black transition-all hover:scale-110" style={{ background: c, border: company.themeColor === c ? `2px solid ${c}` : '2px solid transparent' } as any} onClick={() => {}} />
                  ))}
                </div>
              </div>
              <Button type="submit" className="bg-amber-500 hover:bg-amber-600 text-white gap-2" disabled={updateMutation.isPending}><Save className="w-4 h-4" /> Save Changes</Button>
            </form>
          ) : (
            <div className="glass-card p-8 text-center text-muted-foreground">
              <Building2 className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
              <p>No company selected. Create or select a workspace.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="workspaces" className="mt-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold">Your Workspaces</h3>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild><Button size="sm" className="bg-amber-500 hover:bg-amber-600 text-white gap-1"><Plus className="w-3.5 h-3.5" /> New Workspace</Button></DialogTrigger>
              <DialogContent className="bg-[#0F0F0F] border-white/10"><DialogHeader><DialogTitle>Create New Workspace</DialogTitle></DialogHeader>
                <form onSubmit={handleCreate} className="space-y-4">
                  <div className="space-y-2"><Label>Company Name *</Label><Input name="name" placeholder="WEGE Metal Company" required className="bg-white/5 border-white/10" /></div>
                  <div className="space-y-2"><Label>Contact Email</Label><Input name="contactEmail" type="email" placeholder="admin@company.com" className="bg-white/5 border-white/10" /></div>
                  <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white" disabled={createMutation.isPending}>{createMutation.isPending ? "Creating..." : "Create Workspace"}</Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
          <div className="space-y-2">
            {(companies || []).map(c => (
              <div key={c.id} className={`glass-card p-4 flex items-center gap-4 cursor-pointer hover:bg-white/[0.04] transition-colors ${companyId === c.id ? "ring-1 ring-amber-500/50" : ""}`} onClick={() => switchCompany(c.id)}>
                <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ background: `${c.themeColor || "#D97706"}20` }}><Building2 className="w-5 h-5" style={{ color: c.themeColor || "#D97706" }} /></div>
                <div className="flex-1"><div className="text-sm font-medium">{c.name}</div><div className="text-xs text-muted-foreground">{c.contactEmail || "No email"}</div></div>
                {companyId === c.id && <span className="text-[10px] font-medium px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-500">Active</span>}
              </div>
            ))}
            {(companies || []).length === 0 && <div className="text-center py-8 text-muted-foreground text-sm">No workspaces yet. Create your first workspace.</div>}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
