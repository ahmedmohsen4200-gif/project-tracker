import { useState, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { Bell, Check, Trash2, FileCheck, FileText, Truck, Receipt, AlertTriangle, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";

const TYPE_CONFIG: Record<string, { icon: React.ComponentType<{ className?: string }>; color: string; label: string }> = {
  submittal_pending: { icon: FileCheck, color: "text-amber-500 bg-amber-500/10", label: "Submittal" },
  drawing_pending: { icon: FileText, color: "text-blue-500 bg-blue-500/10", label: "Drawing" },
  fabrication_delay: { icon: AlertTriangle, color: "text-red-400 bg-red-400/10", label: "Fabrication" },
  delivery_delay: { icon: Truck, color: "text-orange-500 bg-orange-500/10", label: "Delivery" },
  payment_pending: { icon: Receipt, color: "text-violet-500 bg-violet-500/10", label: "Payment" },
  payment_received: { icon: Receipt, color: "text-emerald-500 bg-emerald-500/10", label: "Payment" },
  due_date: { icon: Clock, color: "text-cyan-500 bg-cyan-500/10", label: "Due Date" },
  general: { icon: Bell, color: "text-muted-foreground bg-white/5", label: "General" },
};

export default function NotificationsPage() {
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const utils = trpc.useUtils();
  const { data: notifications } = trpc.notifications.list.useQuery({ companyId }, { enabled: companyId > 0 });
  const markRead = trpc.notifications.markRead.useMutation({ onSuccess: () => utils.notifications.list.invalidate() });
  const markAllRead = trpc.notifications.markAllRead.useMutation({ onSuccess: () => { utils.notifications.list.invalidate(); utils.notifications.unreadCount.invalidate(); } });
  const deleteNotif = trpc.notifications.delete.useMutation({ onSuccess: () => utils.notifications.list.invalidate() });

  // Demo data if none exist
  const displayNotifications = useMemo(() => {
    if (notifications && notifications.length > 0) return notifications;
    return [
      { id: 1, title: "Submittal SM-042 pending reply", message: "Consultant reply not received for 5 days", type: "submittal_pending" as const, isRead: false, createdAt: new Date(Date.now() - 3600000) },
      { id: 2, title: "Shop Drawing SD-018 approved", message: "Curtain Wall Level 6-10 drawings approved with comments", type: "drawing_pending" as const, isRead: false, createdAt: new Date(Date.now() - 7200000) },
      { id: 3, title: "Delivery DN-2024-008 delayed", message: "Aluminum profiles delivery delayed by 3 days", type: "delivery_delay" as const, isRead: true, createdAt: new Date(Date.now() - 86400000) },
      { id: 4, title: "Payment PC-003 under review", message: "Payment certificate for $275,000 is under consultant review", type: "payment_pending" as const, isRead: true, createdAt: new Date(Date.now() - 172800000) },
      { id: 5, title: "Due date approaching", message: "Submittal SM-045 due in 2 days", type: "due_date" as const, isRead: false, createdAt: new Date(Date.now() - 43200000) },
    ];
  }, [notifications]);

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Notifications</h2><p className="text-sm text-muted-foreground mt-0.5">Stay updated on your projects</p></div>
        <Button variant="outline" size="sm" className="border-white/10 gap-2" onClick={() => markAllRead.mutate({ companyId })}>
          <Check className="w-4 h-4" /> Mark All Read
        </Button>
      </div>

      <div className="space-y-2">
        {displayNotifications.map(n => {
          const config = TYPE_CONFIG[n.type] || TYPE_CONFIG.general;
          const Icon = config.icon;
          return (
            <div key={n.id} className={`glass-card p-4 flex items-start gap-4 transition-all ${!n.isRead ? "bg-amber-500/[0.02] border-amber-500/20" : ""}`}>
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center flex-shrink-0 ${config.color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <h4 className={`text-sm ${!n.isRead ? "font-semibold" : "font-medium"}`}>{n.title}</h4>
                  {!n.isRead && <span className="w-2 h-2 rounded-full bg-amber-500 flex-shrink-0" />}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">{n.message}</p>
                <p className="text-[10px] text-muted-foreground/60 mt-2">{new Date(n.createdAt).toLocaleString()}</p>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                {!n.isRead && (
                  <Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => markRead.mutate({ id: n.id })} title="Mark as read">
                    <Check className="w-3.5 h-3.5" />
                  </Button>
                )}
                <Button variant="ghost" size="icon" className="h-7 w-7 text-red-400" onClick={() => deleteNotif.mutate({ id: n.id })} title="Delete">
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              </div>
            </div>
          );
        })}
        {displayNotifications.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Bell className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
            <p>No notifications yet.</p>
          </div>
        )}
      </div>
    </div>
  );
}
