import { useState, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { Users, UserPlus, Shield, HardHat, FileText, Truck, Receipt, PenTool } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const ROLE_OPTIONS = [
  { value: "admin", label: "Admin", icon: Shield },
  { value: "estimation_engineer", label: "Estimation Engineer", icon: PenTool },
  { value: "technical_engineer", label: "Technical Engineer", icon: FileText },
  { value: "procurement_fabrication", label: "Procurement / Fabrication", icon: Truck },
  { value: "site_engineer", label: "Site Engineer", icon: HardHat },
  { value: "accounts_finance", label: "Accounts / Finance", icon: Receipt },
];

const ROLE_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  admin: Shield, estimation_engineer: PenTool, technical_engineer: FileText,
  procurement_fabrication: Truck, site_engineer: HardHat, accounts_finance: Receipt,
};

export default function UsersPage() {
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [isOpen, setIsOpen] = useState(false);
  const [inviteEmail, setInviteEmail] = useState("");
  const [inviteRole, setInviteRole] = useState("site_engineer");
  const utils = trpc.useUtils();

  const { data: members } = trpc.companies.getMembers.useQuery({ companyId }, { enabled: companyId > 0 });
  const { data: allUsers } = trpc.auth.me.useQuery();

  const inviteMutation = trpc.companies.addMember.useMutation({
    onSuccess: () => {
      utils.companies.getMembers.invalidate();
      setIsOpen(false);
      setInviteEmail("");
    },
  });

  // For demo, show current user as the only real user
  const memberList = useMemo(() => {
    if (!members) return [];
    return members.map(m => ({
      ...m,
      // In a real app, you'd fetch user details
      name: m.userId === allUsers?.id ? (allUsers?.name || "You") : `User ${m.userId}`,
      email: m.userId === allUsers?.id ? (allUsers?.email || "") : "",
      avatar: allUsers?.avatar || "",
    }));
  }, [members, allUsers]);

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Team Members</h2><p className="text-sm text-muted-foreground">Manage users and their roles</p></div>
        <Dialog open={isOpen} onOpenChange={setIsOpen}>
          <DialogTrigger asChild>
            <Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2">
              <UserPlus className="w-4 h-4" /> Invite Member
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md bg-[#0F0F0F] border-white/10">
            <DialogHeader><DialogTitle>Invite Team Member</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2"><Label>Email Address</Label><Input value={inviteEmail} onChange={e => setInviteEmail(e.target.value)} placeholder="colleague@company.com" className="bg-white/5 border-white/10" /></div>
              <div className="space-y-2"><Label>Role</Label>
                <Select value={inviteRole} onValueChange={setInviteRole}>
                  <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent>{ROLE_OPTIONS.map(r => <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <Button
                className="w-full bg-amber-500 hover:bg-amber-600 text-white"
                onClick={() => {
                  // In a real app, send invitation email
                  // For demo, we show the concept
                  inviteMutation.mutate({ companyId, userId: 0, companyRole: inviteRole as any });
      alert(`Invitation would be sent to ${inviteEmail} with role: ${inviteRole}`);
                  setIsOpen(false);
                }}
              >
                Send Invitation
              </Button>
              <p className="text-xs text-muted-foreground text-center">
                An email invitation will be sent to the user with a link to join.
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Role Legend */}
      <div className="glass-card p-4">
        <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-3">Role Permissions</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {ROLE_OPTIONS.map(role => {
            const Icon = role.icon;
            return (
              <div key={role.value} className="flex items-center gap-2 text-xs">
                <Icon className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-muted-foreground">{role.label}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Members List */}
      <div className="space-y-3">
        {memberList.map(member => {
          const RoleIcon = ROLE_ICONS[member.companyRole] || Users;
          return (
            <div key={member.id} className="glass-card p-4 flex items-center gap-4 hover:bg-white/[0.04] transition-colors">
              <div className="w-10 h-10 rounded-full bg-amber-500/10 flex items-center justify-center ring-1 ring-amber-500/20">
                <span className="text-sm font-medium text-amber-500">{(member.name || "U").charAt(0).toUpperCase()}</span>
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium truncate">{member.name}</div>
                <div className="text-xs text-muted-foreground">{member.email}</div>
              </div>
              <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white/5">
                <RoleIcon className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-xs text-muted-foreground">{member.companyRole.replace(/_/g, " ")}</span>
              </div>
              <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${member.isActive ? "bg-emerald-500/10 text-emerald-500" : "bg-red-500/10 text-red-400"}`}>
                {member.isActive ? "Active" : "Inactive"}
              </span>
            </div>
          );
        })}
        {memberList.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            No team members yet. Invite your first team member to get started.
          </div>
        )}
      </div>
    </div>
  );
}
