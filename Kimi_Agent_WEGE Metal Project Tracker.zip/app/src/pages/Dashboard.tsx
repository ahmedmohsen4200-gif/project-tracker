import { useMemo } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  FolderKanban, FileCheck, Receipt,
  TrendingUp, Clock, DollarSign
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";

const STATUS_COLORS: Record<string, string> = {
  tender: "#6B7280",
  awarded: "#3B82F6",
  shop_drawings: "#8B5CF6",
  technical_submittal: "#F59E0B",
  fabrication: "#EC4899",
  delivery_to_site: "#10B981",
  installation: "#06B6D4",
  payment: "#D97706",
  completed: "#22C55E",
  on_hold: "#F97316",
  cancelled: "#EF4444",
};

const STAGE_LABELS: Record<string, string> = {
  estimation: "Estimation",
  contract: "Contract",
  technical_submittal: "Technical Submittal",
  shop_drawings: "Shop Drawings",
  fabrication: "Fabrication",
  delivery: "Delivery",
  installation: "Installation",
  payments: "Payments",
  completed: "Completed",
};

export default function Dashboard() {
  const navigate = useNavigate();
  const [companyId] = useMemo(() => {
    const stored = localStorage.getItem("pl_company_id");
    return [stored ? parseInt(stored) : 0];
  }, []);

  const { data: stats } = trpc.dashboard.stats.useQuery(
    { companyId },
    { enabled: companyId > 0, refetchInterval: 30000 }
  );
  const { data: projects } = trpc.projects.list.useQuery(
    { companyId },
    { enabled: companyId > 0 }
  );

  const statusChartData = useMemo(() => {
    if (!stats?.statusBreakdown) return [];
    return stats.statusBreakdown.map((s) => ({
      name: s.status.replace(/_/g, " ").replace(/\b\w/g, (l) => l.toUpperCase()),
      value: s.count,
      fill: STATUS_COLORS[s.status] || "#6B7280",
    }));
  }, [stats]);

  const stageChartData = useMemo(() => {
    if (!stats?.stageBreakdown) return [];
    return stats.stageBreakdown.map((s) => ({
      name: STAGE_LABELS[s.stage] || s.stage,
      value: s.count,
    }));
  }, [stats]);

  const recentProjects = useMemo(() => {
    return (projects || []).slice(0, 5);
  }, [projects]);

  const formatCurrency = (val: string) => {
    const num = parseFloat(val);
    if (isNaN(num)) return "$0.00";
    if (num >= 1_000_000) return `$${(num / 1_000_000).toFixed(2)}M`;
    if (num >= 1_000) return `$${(num / 1_000).toFixed(1)}K`;
    return `$${num.toFixed(2)}`;
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          icon={FolderKanban}
          label="Total Projects"
          value={stats?.totalProjects ?? 0}
          sublabel="Active contracts"
          color="amber"
        />
        <KpiCard
          icon={DollarSign}
          label="Contract Value"
          value={formatCurrency(stats?.totalContractValue || "0")}
          sublabel="Total portfolio"
          color="emerald"
        />
        <KpiCard
          icon={FileCheck}
          label="Pending Submittals"
          value={stats?.pendingSubmittals ?? 0}
          sublabel="Awaiting reply"
          color="blue"
        />
        <KpiCard
          icon={Receipt}
          label="Total Collected"
          value={formatCurrency(stats?.paymentStats?.totalReceived || "0")}
          sublabel="Payments received"
          color="violet"
        />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold mb-4">Projects by Stage</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stageChartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                <XAxis dataKey="name" tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    background: "#1a1a1a",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
                <Bar dataKey="value" fill="#D97706" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold mb-4">Projects by Status</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusChartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={90}
                  paddingAngle={2}
                  dataKey="value"
                >
                  {statusChartData.map((entry, index) => (
                    <Cell key={index} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    background: "#1a1a1a",
                    border: "1px solid rgba(255,255,255,0.1)",
                    borderRadius: "8px",
                    fontSize: "12px",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {statusChartData.map((s) => (
              <div key={s.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <div className="w-2 h-2 rounded-full" style={{ background: s.fill }} />
                <span>{s.name}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Payment Overview + Recent Projects */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="glass-card p-5 lg:col-span-1">
          <h3 className="text-sm font-semibold mb-4">Financial Overview</h3>
          <div className="space-y-4">
            <FinancialRow
              label="Submitted"
              value={formatCurrency(stats?.paymentStats?.totalSubmitted || "0")}
              icon={TrendingUp}
            />
            <FinancialRow
              label="Approved"
              value={formatCurrency(stats?.paymentStats?.totalApproved || "0")}
              icon={FileCheck}
            />
            <FinancialRow
              label="Received"
              value={formatCurrency(stats?.paymentStats?.totalReceived || "0")}
              icon={DollarSign}
              highlight
            />
            <FinancialRow
              label="Pending"
              value={formatCurrency(stats?.paymentStats?.totalPending || "0")}
              icon={Clock}
              warning
            />
          </div>
        </div>

        <div className="glass-card p-5 lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold">Recent Projects</h3>
            <button
              onClick={() => navigate("/projects")}
              className="text-xs text-amber-500 hover:text-amber-400 transition-colors"
            >
              View All
            </button>
          </div>
          <div className="space-y-2">
            {recentProjects.map((p) => (
              <div
                key={p.id}
                onClick={() => navigate(`/projects/${p.id}`)}
                className="flex items-center justify-between p-3 rounded-lg hover:bg-white/5 transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center">
                    <FolderKanban className="w-4 h-4 text-amber-500" />
                  </div>
                  <div>
                    <div className="text-sm font-medium group-hover:text-amber-500 transition-colors">
                      {p.name}
                    </div>
                    <div className="text-xs text-muted-foreground">{p.client}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs font-mono-metrics text-muted-foreground">
                    {p.projectCode}
                  </div>
                  <span
                    className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium mt-1"
                    style={{
                      background: `${STATUS_COLORS[p.status] || "#6B7280"}20`,
                      color: STATUS_COLORS[p.status] || "#6B7280",
                    }}
                  >
                    {p.status.replace(/_/g, " ")}
                  </span>
                </div>
              </div>
            ))}
            {recentProjects.length === 0 && (
              <div className="text-center py-8 text-muted-foreground text-sm">
                No projects yet. Create your first project to get started.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function KpiCard({
  icon: Icon,
  label,
  value,
  sublabel,
  color,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string | number;
  sublabel: string;
  color: string;
}) {
  const colorMap: Record<string, string> = {
    amber: "text-amber-500 bg-amber-500/10",
    emerald: "text-emerald-500 bg-emerald-500/10",
    blue: "text-blue-500 bg-blue-500/10",
    violet: "text-violet-500 bg-violet-500/10",
  };
  const cls = colorMap[color] || colorMap.amber;

  return (
    <div className="glass-card p-5 hover:bg-white/[0.04] transition-colors">
      <div className="flex items-center justify-between mb-3">
        <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${cls}`}>
          <Icon className="w-[18px] h-[18px]" />
        </div>
      </div>
      <div className="text-2xl font-semibold font-mono-metrics">{value}</div>
      <div className="text-sm text-muted-foreground mt-0.5">{label}</div>
      <div className="text-xs text-muted-foreground/60 mt-1">{sublabel}</div>
    </div>
  );
}

function FinancialRow({
  label,
  value,
  icon: Icon,
  highlight,
  warning,
}: {
  label: string;
  value: string;
  icon: React.ComponentType<{ className?: string }>;
  highlight?: boolean;
  warning?: boolean;
}) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-white/5 last:border-0">
      <div className="flex items-center gap-2">
        <Icon
          className={`w-4 h-4 ${
            highlight ? "text-emerald-500" : warning ? "text-amber-500" : "text-muted-foreground"
          }`}
        />
        <span className="text-sm text-muted-foreground">{label}</span>
      </div>
      <span
        className={`text-sm font-mono-metrics font-medium ${
          highlight ? "text-emerald-500" : warning ? "text-amber-500" : "text-white"
        }`}
      >
        {value}
      </span>
    </div>
  );
}
