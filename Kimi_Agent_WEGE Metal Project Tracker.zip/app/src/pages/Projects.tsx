import { useState } from "react";
import { useNavigate, useParams } from "react-router";
import { trpc } from "@/providers/trpc";
import {
  Plus, Search, Filter, Pencil, Trash2, ChevronRight,
  Building2, MapPin, User, Calendar, DollarSign, FileText, FileCheck, Package, Truck, HardHat, Receipt, ArrowLeft
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const STATUS_OPTIONS = [
  "tender", "awarded", "shop_drawings", "technical_submittal",
  "fabrication", "delivery_to_site", "installation", "payment",
  "completed", "on_hold", "cancelled",
];
const STAGE_OPTIONS = [
  "estimation", "contract", "technical_submittal", "shop_drawings",
  "fabrication", "delivery", "installation", "payments", "completed",
];

const STATUS_COLORS: Record<string, string> = {
  tender: "#6B7280", awarded: "#3B82F6", shop_drawings: "#8B5CF6",
  technical_submittal: "#F59E0B", fabrication: "#EC4899",
  delivery_to_site: "#10B981", installation: "#06B6D4",
  payment: "#D97706", completed: "#22C55E",
  on_hold: "#F97316", cancelled: "#EF4444",
};

export default function ProjectsPage() {
  const { id } = useParams();
  if (id) return <ProjectDetail projectId={parseInt(id)} />;
  return <ProjectList />;
}

function ProjectList() {
  const navigate = useNavigate();
  const [companyId] = useState(() => {
    const stored = localStorage.getItem("pl_company_id");
    return stored ? parseInt(stored) : 0;
  });
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [stageFilter, setStageFilter] = useState("");
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const utils = trpc.useUtils();

  const { data: projects, isLoading } = trpc.projects.list.useQuery({
    companyId,
    search: search || undefined,
    status: statusFilter || undefined,
    stage: stageFilter || undefined,
  });

  const createMutation = trpc.projects.create.useMutation({
    onSuccess: () => {
      utils.projects.list.invalidate();
      setIsCreateOpen(false);
    },
  });

  // delete handled in detail view

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    createMutation.mutate({
      companyId,
      projectCode: fd.get("projectCode") as string,
      name: fd.get("name") as string,
      client: fd.get("client") as string,
      consultant: fd.get("consultant") as string || undefined,
      location: fd.get("location") as string || undefined,
      scopeOfWork: fd.get("scopeOfWork") as string || undefined,
      projectManager: fd.get("projectManager") as string || undefined,
      startDate: fd.get("startDate") as string || undefined,
      expectedFinishDate: fd.get("expectedFinishDate") as string || undefined,
      contractDate: fd.get("contractDate") as string || undefined,
      contractValue: fd.get("contractValue") as string || undefined,
      status: (fd.get("status") as string) || "tender",
      currentStage: (fd.get("currentStage") as string) || "estimation",
      notes: fd.get("notes") as string || undefined,
    });
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">Projects</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Manage all your construction projects
          </p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2">
              <Plus className="w-4 h-4" /> New Project
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-[#0F0F0F] border-white/10">
            <DialogHeader>
              <DialogTitle>Create New Project</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Project Code *</Label>
                  <Input name="projectCode" placeholder="PRJ-001" required className="bg-white/5 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label>Project Name *</Label>
                  <Input name="name" placeholder="Project Name" required className="bg-white/5 border-white/10" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Client *</Label>
                  <Input name="client" placeholder="Client Name" required className="bg-white/5 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label>Consultant</Label>
                  <Input name="consultant" placeholder="Consultant Name" className="bg-white/5 border-white/10" />
                </div>
              </div>
              <div className="space-y-2">
                <Label>Location</Label>
                <Input name="location" placeholder="Project Location" className="bg-white/5 border-white/10" />
              </div>
              <div className="space-y-2">
                <Label>Scope of Work</Label>
                <Textarea name="scopeOfWork" placeholder="Describe the scope..." className="bg-white/5 border-white/10" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Project Manager</Label>
                  <Input name="projectManager" placeholder="Name" className="bg-white/5 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label>Contract Value</Label>
                  <Input name="contractValue" type="number" step="0.01" placeholder="0.00" className="bg-white/5 border-white/10" />
                </div>
              </div>
              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input name="startDate" type="date" className="bg-white/5 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label>Expected Finish</Label>
                  <Input name="expectedFinishDate" type="date" className="bg-white/5 border-white/10" />
                </div>
                <div className="space-y-2">
                  <Label>Contract Date</Label>
                  <Input name="contractDate" type="date" className="bg-white/5 border-white/10" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Status</Label>
                  <Select name="status" defaultValue="tender">
                    <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STATUS_OPTIONS.map((s) => (
                        <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Current Stage</Label>
                  <Select name="currentStage" defaultValue="estimation">
                    <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {STAGE_OPTIONS.map((s) => (
                        <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Notes</Label>
                <Textarea name="notes" placeholder="Additional notes..." className="bg-white/5 border-white/10" />
              </div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white" disabled={createMutation.isPending}>
                {createMutation.isPending ? "Creating..." : "Create Project"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <div className="flex gap-3">
        <div className="relative flex-1 max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search projects..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9 bg-white/5 border-white/10"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-40 bg-white/5 border-white/10">
            <Filter className="w-4 h-4 mr-2" /> {statusFilter || "All Status"}
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Status</SelectItem>
            {STATUS_OPTIONS.map((s) => (
              <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select value={stageFilter} onValueChange={setStageFilter}>
          <SelectTrigger className="w-40 bg-white/5 border-white/10">
            <Filter className="w-4 h-4 mr-2" /> {stageFilter || "All Stages"}
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Stages</SelectItem>
            {STAGE_OPTIONS.map((s) => (
              <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {/* Projects Grid */}
      {isLoading ? (
        <div className="text-center py-12 text-muted-foreground">Loading projects...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {(projects || []).map((project) => (
            <div
              key={project.id}
              onClick={() => navigate(`/projects/${project.id}`)}
              className="glass-card p-5 cursor-pointer hover:bg-white/[0.04] transition-all group"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <div className="text-xs font-mono-metrics text-muted-foreground mb-1">{project.projectCode}</div>
                  <h3 className="font-semibold text-sm group-hover:text-amber-500 transition-colors line-clamp-1">
                    {project.name}
                  </h3>
                </div>
                <span
                  className="px-2 py-0.5 rounded-full text-[10px] font-medium"
                  style={{
                    background: `${STATUS_COLORS[project.status] || "#6B7280"}20`,
                    color: STATUS_COLORS[project.status] || "#6B7280",
                  }}
                >
                  {project.status.replace(/_/g, " ")}
                </span>
              </div>
              <div className="space-y-2 text-xs text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Building2 className="w-3.5 h-3.5" />
                  <span className="truncate">{project.client}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5" />
                  <span className="truncate">{project.location || "N/A"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="w-3.5 h-3.5" />
                  <span>{project.projectManager || "N/A"}</span>
                </div>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-3.5 h-3.5" />
                  <span className="font-mono-metrics">
                    {project.contractValue ? `$${parseFloat(project.contractValue).toLocaleString()}` : "$0"}
                  </span>
                </div>
              </div>
              <div className="flex items-center justify-between mt-4 pt-3 border-t border-white/5">
                <span className="text-[10px] text-muted-foreground">
                  Stage: {project.currentStage.replace(/_/g, " ")}
                </span>
                <ChevronRight className="w-4 h-4 text-muted-foreground group-hover:text-amber-500 transition-colors" />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function ProjectDetail({ projectId }: { projectId: number }) {
  const navigate = useNavigate();
  const utils = trpc.useUtils();
  const { data: project, isLoading } = trpc.projects.getById.useQuery({ id: projectId });
  const [isEditOpen, setIsEditOpen] = useState(false);

  const updateMutation = trpc.projects.update.useMutation({
    onSuccess: () => {
      utils.projects.getById.invalidate({ id: projectId });
      setIsEditOpen(false);
    },
  });

  const deleteMutation = trpc.projects.delete.useMutation({
    onSuccess: () => navigate("/projects"),
  });

  if (isLoading || !project) {
    return <div className="text-center py-12 text-muted-foreground">Loading...</div>;
  }

  const handleUpdate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    updateMutation.mutate({
      id: projectId,
      projectCode: fd.get("projectCode") as string,
      name: fd.get("name") as string,
      client: fd.get("client") as string,
      consultant: fd.get("consultant") as string || undefined,
      location: fd.get("location") as string || undefined,
      scopeOfWork: fd.get("scopeOfWork") as string || undefined,
      projectManager: fd.get("projectManager") as string || undefined,
      contractValue: fd.get("contractValue") as string || undefined,
      status: fd.get("status") as string || undefined,
      currentStage: fd.get("currentStage") as string || undefined,
      notes: fd.get("notes") as string || undefined,
    });
  };

  const formatDate = (d: Date | null) => d ? new Date(d).toLocaleDateString() : "N/A";

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => navigate("/projects")}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-semibold">{project.name}</h2>
            <span
              className="px-2.5 py-0.5 rounded-full text-xs font-medium"
              style={{
                background: `${STATUS_COLORS[project.status] || "#6B7280"}20`,
                color: STATUS_COLORS[project.status] || "#6B7280",
              }}
            >
              {project.status.replace(/_/g, " ")}
            </span>
          </div>
          <p className="text-sm text-muted-foreground">{project.projectCode} | {project.client}</p>
        </div>
        <div className="flex gap-2">
          <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
            <DialogTrigger asChild>
              <Button variant="outline" size="sm" className="gap-1 border-white/10">
                <Pencil className="w-3.5 h-3.5" /> Edit
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-[#0F0F0F] border-white/10">
              <DialogHeader><DialogTitle>Edit Project</DialogTitle></DialogHeader>
              <form onSubmit={handleUpdate} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>Project Code</Label><Input name="projectCode" defaultValue={project.projectCode} className="bg-white/5 border-white/10" /></div>
                  <div className="space-y-2"><Label>Project Name</Label><Input name="name" defaultValue={project.name} className="bg-white/5 border-white/10" /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>Client</Label><Input name="client" defaultValue={project.client} className="bg-white/5 border-white/10" /></div>
                  <div className="space-y-2"><Label>Consultant</Label><Input name="consultant" defaultValue={project.consultant || ""} className="bg-white/5 border-white/10" /></div>
                </div>
                <div className="space-y-2"><Label>Location</Label><Input name="location" defaultValue={project.location || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Scope of Work</Label><Textarea name="scopeOfWork" defaultValue={project.scopeOfWork || ""} className="bg-white/5 border-white/10" /></div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2"><Label>Project Manager</Label><Input name="projectManager" defaultValue={project.projectManager || ""} className="bg-white/5 border-white/10" /></div>
                  <div className="space-y-2"><Label>Contract Value</Label><Input name="contractValue" type="number" step="0.01" defaultValue={project.contractValue || ""} className="bg-white/5 border-white/10" /></div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Status</Label>
                    <Select name="status" defaultValue={project.status}>
                      <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                      <SelectContent>{STATUS_OPTIONS.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Current Stage</Label>
                    <Select name="currentStage" defaultValue={project.currentStage}>
                      <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                      <SelectContent>{STAGE_OPTIONS.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2"><Label>Notes</Label><Textarea name="notes" defaultValue={project.notes || ""} className="bg-white/5 border-white/10" /></div>
                <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white">Save Changes</Button>
              </form>
            </DialogContent>
          </Dialog>
          <Button
            variant="outline"
            size="sm"
            className="gap-1 border-red-500/30 text-red-400 hover:bg-red-500/10"
            onClick={() => { if (confirm("Delete this project?")) deleteMutation.mutate({ id: projectId }); }}
          >
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* Info Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <InfoCard icon={Building2} label="Client" value={project.client} />
        <InfoCard icon={MapPin} label="Location" value={project.location || "N/A"} />
        <InfoCard icon={User} label="Project Manager" value={project.projectManager || "N/A"} />
        <InfoCard icon={DollarSign} label="Contract Value" value={`$${parseFloat(project.contractValue || "0").toLocaleString()}`} />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <InfoCard icon={Calendar} label="Start Date" value={formatDate(project.startDate)} />
        <InfoCard icon={Calendar} label="Expected Finish" value={formatDate(project.expectedFinishDate)} />
        <InfoCard icon={FileText} label="Contract Date" value={formatDate(project.contractDate)} />
      </div>

      {/* Scope */}
      {project.scopeOfWork && (
        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold mb-2">Scope of Work</h3>
          <p className="text-sm text-muted-foreground whitespace-pre-wrap">{project.scopeOfWork}</p>
        </div>
      )}
      {project.notes && (
        <div className="glass-card p-5">
          <h3 className="text-sm font-semibold mb-2">Notes</h3>
          <p className="text-sm text-muted-foreground whitespace-pre-wrap">{project.notes}</p>
        </div>
      )}

      {/* Quick Links */}
      <div className="glass-card p-5">
        <h3 className="text-sm font-semibold mb-4">Project Tracking</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {[
            { label: "Submittals", path: `/submittals?project=${projectId}`, icon: FileCheck },
            { label: "Shop Drawings", path: `/drawings?project=${projectId}`, icon: FileText },
            { label: "Quantities", path: `/quantities?project=${projectId}`, icon: Package },
            { label: "Deliveries", path: `/deliveries?project=${projectId}`, icon: Truck },
            { label: "Installation", path: `/installation?project=${projectId}`, icon: HardHat },
            { label: "Payments", path: `/payments?project=${projectId}`, icon: Receipt },
          ].map((link) => (
            <button
              key={link.path}
              onClick={() => navigate(link.path)}
              className="flex items-center gap-3 p-3 rounded-lg bg-white/5 hover:bg-amber-500/10 hover:border-amber-500/20 border border-white/5 transition-all group text-left"
            >
              <link.icon className="w-5 h-5 text-muted-foreground group-hover:text-amber-500 transition-colors" />
              <span className="text-sm group-hover:text-amber-500 transition-colors">{link.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

function InfoCard({ icon: Icon, label, value }: { icon: React.ComponentType<{ className?: string }>; label: string; value: string }) {
  return (
    <div className="glass-card p-4">
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4 text-muted-foreground" />
        <span className="text-xs text-muted-foreground">{label}</span>
      </div>
      <div className="text-sm font-medium truncate">{value}</div>
    </div>
  );
}
