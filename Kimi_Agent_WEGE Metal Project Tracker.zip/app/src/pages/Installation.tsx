import { useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Plus, Pencil, Trash2, Search, HardHat } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function InstallationPage() {
  const [searchParams] = useSearchParams();
  const projectIdParam = searchParams.get("project");
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data } = trpc.installations.list.useQuery({ companyId, projectId: projectIdParam ? parseInt(projectIdParam) : undefined });
  const createMut = trpc.installations.create.useMutation({ onSuccess: () => { utils.installations.list.invalidate(); setIsOpen(false); } });
  const updateMut = trpc.installations.update.useMutation({ onSuccess: () => { utils.installations.list.invalidate(); setEditId(null); } });
  const deleteMut = trpc.installations.delete.useMutation({ onSuccess: () => utils.installations.list.invalidate() });
  const projects = trpc.projects.list.useQuery({ companyId });
  const projectMap = useMemo(() => { const m: Record<number, string> = {}; (projects.data || []).forEach(p => m[p.id] = p.name); return m; }, [projects.data]);
  const filtered = useMemo(() => !data ? [] : search ? data.filter(i => i.itemName.toLowerCase().includes(search.toLowerCase())) : data, [data, search]);
  const editing = editId ? data?.find(i => i.id === editId) : null;

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      projectId: parseInt(fd.get("projectId") as string), companyId,
      itemName: fd.get("itemName"),
      installedQuantity: fd.get("installedQuantity") || undefined,
      installationDate: fd.get("installationDate") || undefined,
      areaZone: fd.get("areaZone") || undefined,
      floor: fd.get("floor") || undefined,
      teamName: fd.get("teamName") || undefined,
      siteNotes: fd.get("siteNotes") || undefined,
      remainingQuantity: fd.get("remainingQuantity") || undefined,
      installationPercentage: fd.get("installationPercentage") || undefined,
    };
    if (editId) { payload.id = editId; delete payload.projectId; delete payload.companyId; updateMut.mutate(payload); }
    else createMut.mutate(payload);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Installation Tracking</h2><p className="text-sm text-muted-foreground">Track installation progress by area and team</p></div>
        <Dialog open={isOpen} onOpenChange={(v) => { setIsOpen(v); setEditId(null); }}>
          <DialogTrigger asChild><Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2"><Plus className="w-4 h-4" /> Add Record</Button></DialogTrigger>
          <DialogContent className="max-w-xl bg-[#0F0F0F] border-white/10 max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{editId ? "Edit" : "Add"} Installation Record</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-2"><Label>Project</Label><Select name="projectId" defaultValue={projectIdParam || editing?.projectId?.toString()}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{(projects.data || []).map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label>Item Name *</Label><Input name="itemName" defaultValue={editing?.itemName} required className="bg-white/5 border-white/10" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Installed Qty</Label><Input name="installedQuantity" type="number" step="0.01" defaultValue={editing?.installedQuantity || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Installation Date</Label><Input name="installationDate" type="date" defaultValue={editing?.installationDate ? new Date(editing.installationDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2"><Label>Area/Zone</Label><Input name="areaZone" defaultValue={editing?.areaZone || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Floor</Label><Input name="floor" defaultValue={editing?.floor || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Team</Label><Input name="teamName" defaultValue={editing?.teamName || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Remaining Qty</Label><Input name="remainingQuantity" type="number" step="0.01" defaultValue={editing?.remainingQuantity || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Completion %</Label><Input name="installationPercentage" type="number" step="0.01" defaultValue={editing?.installationPercentage || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="space-y-2"><Label>Site Notes</Label><Textarea name="siteNotes" defaultValue={editing?.siteNotes || ""} className="bg-white/5 border-white/10" /></div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white">{editId ? "Save" : "Create"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="relative max-w-xs"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><Input placeholder="Search..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10" /></div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {filtered.map(item => {
          const pct = parseFloat(item.installationPercentage || "0");
          return (
            <div key={item.id} className="glass-card p-5 hover:bg-white/[0.04] transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center"><HardHat className="w-5 h-5 text-emerald-500" /></div>
                  <div>
                    <div className="font-medium">{item.itemName}</div>
                    <div className="text-xs text-muted-foreground">{projectMap[item.projectId] || "—"}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-semibold font-mono-metrics">{pct}%</div>
                </div>
              </div>
              <div className="mt-3"><div className="w-full h-2 bg-white/10 rounded-full overflow-hidden"><div className="h-full rounded-full transition-all" style={{ width: `${Math.min(pct, 100)}%`, background: pct >= 100 ? "#22C55E" : pct >= 50 ? "#D97706" : "#EF4444" }} /></div></div>
              <div className="grid grid-cols-3 gap-4 mt-4 pt-3 border-t border-white/5 text-xs">
                <div><div className="text-muted-foreground">Installed</div><div className="font-mono-metrics font-medium">{item.installedQuantity || "—"}</div></div>
                <div><div className="text-muted-foreground">Remaining</div><div className="font-mono-metrics font-medium">{item.remainingQuantity || "—"}</div></div>
                <div><div className="text-muted-foreground">Area</div><div className="text-muted-foreground">{item.areaZone || "—"} {item.floor ? `/ F${item.floor}` : ""}</div></div>
              </div>
              <div className="flex items-center justify-between mt-3 pt-3 border-t border-white/5">
                <div className="text-xs text-muted-foreground">Team: {item.teamName || "—"}</div>
                <div className="flex gap-1"><Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditId(item.id); setIsOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button><Button variant="ghost" size="icon" className="h-7 w-7 text-red-400" onClick={() => { if (confirm("Delete?")) deleteMut.mutate({ id: item.id }); }}><Trash2 className="w-3.5 h-3.5" /></Button></div>
              </div>
            </div>
          );
        })}
      </div>
      {filtered.length === 0 && <div className="text-center py-12 text-muted-foreground">No installation records found</div>}
    </div>
  );
}
