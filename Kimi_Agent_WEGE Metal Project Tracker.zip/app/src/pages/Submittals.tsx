import { useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const REPLY_STATUS = ["pending", "approved", "approved_with_comments", "rejected", "revise_and_resubmit"];
const STATUS_COLORS: Record<string, string> = {
  pending: "#F59E0B", approved: "#22C55E", approved_with_comments: "#3B82F6",
  rejected: "#EF4444", revise_and_resubmit: "#F97316",
};

export default function SubmittalsPage() {
  const [searchParams] = useSearchParams();
  const projectIdParam = searchParams.get("project");
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data } = trpc.submittals.list.useQuery({
    companyId,
    projectId: projectIdParam ? parseInt(projectIdParam) : undefined,
  });

  const createMut = trpc.submittals.create.useMutation({ onSuccess: () => { utils.submittals.list.invalidate(); setIsOpen(false); } });
  const updateMut = trpc.submittals.update.useMutation({ onSuccess: () => { utils.submittals.list.invalidate(); setEditId(null); } });
  const deleteMut = trpc.submittals.delete.useMutation({ onSuccess: () => utils.submittals.list.invalidate() });

  const projects = trpc.projects.list.useQuery({ companyId });
  const projectMap = useMemo(() => {
    const map: Record<number, string> = {};
    (projects.data || []).forEach(p => map[p.id] = p.name);
    return map;
  }, [projects.data]);

  const filtered = useMemo(() => {
    if (!data) return [];
    if (!search) return data;
    return data.filter(s => s.title.toLowerCase().includes(search.toLowerCase()) || (s.submittalNumber || "").toLowerCase().includes(search.toLowerCase()));
  }, [data, search]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload = {
      projectId: parseInt(fd.get("projectId") as string),
      companyId,
      title: fd.get("title") as string,
      submittalNumber: fd.get("submittalNumber") as string || undefined,
      submittedBy: fd.get("submittedBy") as string || undefined,
      submittedDate: fd.get("submittedDate") as string || undefined,
      submittedTo: fd.get("submittedTo") as string || undefined,
      consultantReplyDate: fd.get("consultantReplyDate") as string || undefined,
      replyStatus: (fd.get("replyStatus") as string) || "pending",
      comments: fd.get("comments") as string || undefined,
      revisionNumber: fd.get("revisionNumber") as string || undefined,
      attachmentLink: fd.get("attachmentLink") as string || undefined,
      nextActionRequired: fd.get("nextActionRequired") as string || undefined,
      responsiblePerson: fd.get("responsiblePerson") as string || undefined,
      dueDate: fd.get("dueDate") as string || undefined,
    };
    if (editId) {
      updateMut.mutate({ id: editId, ...payload, projectId: undefined, companyId: undefined } as any);
    } else {
      createMut.mutate(payload);
    }
  };

  const editing = editId ? data?.find(s => s.id === editId) : null;

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Technical Submittals</h2><p className="text-sm text-muted-foreground">Track submittal status and consultant replies</p></div>
        <Dialog open={isOpen} onOpenChange={(v) => { setIsOpen(v); setEditId(null); }}>
          <DialogTrigger asChild><Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2"><Plus className="w-4 h-4" /> Add Submittal</Button></DialogTrigger>
          <DialogContent className="max-w-xl bg-[#0F0F0F] border-white/10 max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{editId ? "Edit" : "Add"} Submittal</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-2"><Label>Project</Label>
                <Select name="projectId" defaultValue={projectIdParam || (editing?.projectId?.toString())}>
                  <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                  <SelectContent>{(projects.data || []).map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Title *</Label><Input name="title" defaultValue={editing?.title} required className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Submittal #</Label><Input name="submittalNumber" defaultValue={editing?.submittalNumber || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Submitted By</Label><Input name="submittedBy" defaultValue={editing?.submittedBy || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Submitted To</Label><Input name="submittedTo" defaultValue={editing?.submittedTo || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Submitted Date</Label><Input name="submittedDate" type="date" defaultValue={editing?.submittedDate ? new Date(editing.submittedDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Reply Status</Label>
                  <Select name="replyStatus" defaultValue={editing?.replyStatus || "pending"}>
                    <SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
                    <SelectContent>{REPLY_STATUS.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>)}</SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Consultant Reply Date</Label><Input name="consultantReplyDate" type="date" defaultValue={editing?.consultantReplyDate ? new Date(editing.consultantReplyDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Revision #</Label><Input name="revisionNumber" defaultValue={editing?.revisionNumber || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="space-y-2"><Label>Comments</Label><Textarea name="comments" defaultValue={editing?.comments || ""} className="bg-white/5 border-white/10" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Responsible Person</Label><Input name="responsiblePerson" defaultValue={editing?.responsiblePerson || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Due Date</Label><Input name="dueDate" type="date" defaultValue={editing?.dueDate ? new Date(editing.dueDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="space-y-2"><Label>Attachment Link</Label><Input name="attachmentLink" defaultValue={editing?.attachmentLink || ""} className="bg-white/5 border-white/10" /></div>
              <div className="space-y-2"><Label>Next Action Required</Label><Textarea name="nextActionRequired" defaultValue={editing?.nextActionRequired || ""} className="bg-white/5 border-white/10" /></div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white">{editId ? "Save" : "Create"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative max-w-xs">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input placeholder="Search submittals..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10" />
      </div>

      <div className="glass-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-muted-foreground text-xs uppercase">
            <tr>
              <th className="text-left p-3">Title</th>
              <th className="text-left p-3">Project</th>
              <th className="text-left p-3">Number</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Submitted</th>
              <th className="text-left p-3">Due Date</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {filtered.map(s => (
              <tr key={s.id} className="hover:bg-white/[0.02] transition-colors">
                <td className="p-3 font-medium">{s.title}</td>
                <td className="p-3 text-muted-foreground">{projectMap[s.projectId] || "—"}</td>
                <td className="p-3 font-mono-metrics text-xs text-muted-foreground">{s.submittalNumber || "—"}</td>
                <td className="p-3">
                  <span className="px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ background: `${STATUS_COLORS[s.replyStatus]}20`, color: STATUS_COLORS[s.replyStatus] }}>
                    {s.replyStatus.replace(/_/g, " ")}
                  </span>
                </td>
                <td className="p-3 text-muted-foreground text-xs">{s.submittedDate ? new Date(s.submittedDate).toLocaleDateString() : "—"}</td>
                <td className="p-3 text-muted-foreground text-xs">{s.dueDate ? new Date(s.dueDate).toLocaleDateString() : "—"}</td>
                <td className="p-3 text-right">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditId(s.id); setIsOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-400" onClick={() => { if (confirm("Delete?")) deleteMut.mutate({ id: s.id }); }}><Trash2 className="w-3.5 h-3.5" /></Button>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No submittals found</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
