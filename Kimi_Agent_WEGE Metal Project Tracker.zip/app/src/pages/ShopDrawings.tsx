import { useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const APPROVAL_STATUS = ["pending", "approved", "approved_with_comments", "rejected", "revise_and_resubmit"];
const ITEM_CATEGORIES = ["curtain_wall", "windows", "doors", "louvers", "cladding", "handrail", "steel_works", "stainless_steel", "glass_works", "skylight", "partitions", "other"];
const STATUS_COLORS: Record<string, string> = { pending: "#F59E0B", approved: "#22C55E", approved_with_comments: "#3B82F6", rejected: "#EF4444", revise_and_resubmit: "#F97316" };

export default function ShopDrawingsPage() {
  const [searchParams] = useSearchParams();
  const projectIdParam = searchParams.get("project");
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data } = trpc.drawings.list.useQuery({ companyId, projectId: projectIdParam ? parseInt(projectIdParam) : undefined });
  const createMut = trpc.drawings.create.useMutation({ onSuccess: () => { utils.drawings.list.invalidate(); setIsOpen(false); } });
  const updateMut = trpc.drawings.update.useMutation({ onSuccess: () => { utils.drawings.list.invalidate(); setEditId(null); } });
  const deleteMut = trpc.drawings.delete.useMutation({ onSuccess: () => utils.drawings.list.invalidate() });
  const projects = trpc.projects.list.useQuery({ companyId });
  const projectMap = useMemo(() => { const m: Record<number, string> = {}; (projects.data || []).forEach(p => m[p.id] = p.name); return m; }, [projects.data]);
  const filtered = useMemo(() => !data ? [] : search ? data.filter(d => d.title.toLowerCase().includes(search.toLowerCase())) : data, [data, search]);
  const editing = editId ? data?.find(d => d.id === editId) : null;

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      projectId: parseInt(fd.get("projectId") as string), companyId,
      title: fd.get("title"), drawingNumber: fd.get("drawingNumber") || undefined,
      revision: fd.get("revision") || undefined, submittedDate: fd.get("submittedDate") || undefined,
      consultantReplyDate: fd.get("consultantReplyDate") || undefined,
      approvalStatus: fd.get("approvalStatus") || "pending",
      approvedQuantity: fd.get("approvedQuantity") || undefined,
      itemCategory: fd.get("itemCategory") || "other",
      attachmentLink: fd.get("attachmentLink") || undefined, notes: fd.get("notes") || undefined,
    };
    if (editId) { payload.id = editId; delete payload.projectId; delete payload.companyId; updateMut.mutate(payload); }
    else createMut.mutate(payload);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Shop Drawings</h2><p className="text-sm text-muted-foreground">Track drawing approvals and quantities</p></div>
        <Dialog open={isOpen} onOpenChange={(v) => { setIsOpen(v); setEditId(null); }}>
          <DialogTrigger asChild><Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2"><Plus className="w-4 h-4" /> Add Drawing</Button></DialogTrigger>
          <DialogContent className="max-w-xl bg-[#0F0F0F] border-white/10 max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{editId ? "Edit" : "Add"} Shop Drawing</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-2"><Label>Project</Label><Select name="projectId" defaultValue={projectIdParam || editing?.projectId?.toString()}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{(projects.data || []).map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Title *</Label><Input name="title" defaultValue={editing?.title} required className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Drawing #</Label><Input name="drawingNumber" defaultValue={editing?.drawingNumber || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2"><Label>Revision</Label><Input name="revision" defaultValue={editing?.revision || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Submitted Date</Label><Input name="submittedDate" type="date" defaultValue={editing?.submittedDate ? new Date(editing.submittedDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Reply Date</Label><Input name="consultantReplyDate" type="date" defaultValue={editing?.consultantReplyDate ? new Date(editing.consultantReplyDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Approval Status</Label><Select name="approvalStatus" defaultValue={editing?.approvalStatus || "pending"}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{APPROVAL_STATUS.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>)}</SelectContent></Select></div>
                <div className="space-y-2"><Label>Approved Qty</Label><Input name="approvedQuantity" type="number" step="0.01" defaultValue={editing?.approvedQuantity || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="space-y-2"><Label>Item Category</Label><Select name="itemCategory" defaultValue={editing?.itemCategory || "other"}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{ITEM_CATEGORIES.map(c => <SelectItem key={c} value={c}>{c.replace(/_/g, " ")}</SelectItem>)}</SelectContent></Select></div>
              <div className="space-y-2"><Label>Attachment Link</Label><Input name="attachmentLink" defaultValue={editing?.attachmentLink || ""} className="bg-white/5 border-white/10" /></div>
              <div className="space-y-2"><Label>Notes</Label><Textarea name="notes" defaultValue={editing?.notes || ""} className="bg-white/5 border-white/10" /></div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white">{editId ? "Save" : "Create"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="relative max-w-xs"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><Input placeholder="Search drawings..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10" /></div>
      <div className="glass-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-white/5 text-muted-foreground text-xs uppercase"><tr><th className="text-left p-3">Title</th><th className="text-left p-3">Project</th><th className="text-left p-3">Drawing #</th><th className="text-left p-3">Category</th><th className="text-left p-3">Status</th><th className="text-left p-3">Approved Qty</th><th className="text-right p-3">Actions</th></tr></thead>
          <tbody className="divide-y divide-white/5">
            {filtered.map(d => (
              <tr key={d.id} className="hover:bg-white/[0.02]">
                <td className="p-3 font-medium">{d.title}</td>
                <td className="p-3 text-muted-foreground">{projectMap[d.projectId] || "—"}</td>
                <td className="p-3 font-mono-metrics text-xs text-muted-foreground">{d.drawingNumber || "—"}</td>
                <td className="p-3 text-xs text-muted-foreground">{d.itemCategory.replace(/_/g, " ")}</td>
                <td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ background: `${STATUS_COLORS[d.approvalStatus]}20`, color: STATUS_COLORS[d.approvalStatus] }}>{d.approvalStatus.replace(/_/g, " ")}</span></td>
                <td className="p-3 font-mono-metrics text-xs">{d.approvedQuantity || "—"}</td>
                <td className="p-3 text-right"><Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => { setEditId(d.id); setIsOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button><Button variant="ghost" size="icon" className="h-8 w-8 text-red-400" onClick={() => { if (confirm("Delete?")) deleteMut.mutate({ id: d.id }); }}><Trash2 className="w-3.5 h-3.5" /></Button></td>
              </tr>
            ))}
            {filtered.length === 0 && <tr><td colSpan={7} className="p-8 text-center text-muted-foreground">No shop drawings found</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
