import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

function getOAuthUrl() {
  const kimiAuthUrl = import.meta.env.VITE_KIMI_AUTH_URL;
  const appID = import.meta.env.VITE_APP_ID;
  const redirectUri = `${window.location.origin}/api/oauth/callback`;
  const state = btoa(redirectUri);

  const url = new URL(`${kimiAuthUrl}/api/oauth/authorize`);
  url.searchParams.set("client_id", appID);
  url.searchParams.set("redirect_uri", redirectUri);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "profile");
  url.searchParams.set("state", state);

  return url.toString();
}

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#050505] relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/3 rounded-full blur-3xl" />
      </div>

      <Card className="w-full max-w-md bg-[#0A0A0A] border-white/10 relative z-10">
        <CardHeader className="text-center pb-2">
          <div className="flex justify-center mb-4">
            <img src="/logo.png" alt="Project Line" className="h-20 w-20" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight">Project Line</h1>
          <p className="text-sm text-muted-foreground mt-1">
            Professional Project Tracking for Aluminum & Metal Works
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="glass-card p-4 text-center">
            <p className="text-sm text-muted-foreground mb-4">
              Sign in to access your project dashboard
            </p>
            <Button
              className="w-full bg-amber-500 hover:bg-amber-600 text-white"
              size="lg"
              onClick={() => {
                window.location.href = getOAuthUrl();
              }}
            >
              Sign in with Kimi
            </Button>
          </div>
          <div className="text-center text-xs text-muted-foreground/60">
            By signing in, you agree to the terms of service and privacy policy.
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
