import { useState, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell
} from "recharts";

const STATUS_COLORS: Record<string, string> = {
  tender: "#6B7280", awarded: "#3B82F6", shop_drawings: "#8B5CF6",
  technical_submittal: "#F59E0B", fabrication: "#EC4899",
  delivery_to_site: "#10B981", installation: "#06B6D4",
  payment: "#D97706", completed: "#22C55E", on_hold: "#F97316", cancelled: "#EF4444",
};

export default function ReportsPage() {
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [reportType, setReportType] = useState("summary");
  const [projectId, setProjectId] = useState<string>("");

  const { data: stats } = trpc.dashboard.stats.useQuery({ companyId }, { enabled: companyId > 0 });
  const { data: projects } = trpc.projects.list.useQuery({ companyId }, { enabled: companyId > 0 });
  const { data: projectItems } = trpc.items.list.useQuery({ companyId, projectId: projectId ? parseInt(projectId) : undefined }, { enabled: companyId > 0 });
  const { data: submittals } = trpc.submittals.list.useQuery({ companyId, projectId: projectId ? parseInt(projectId) : undefined }, { enabled: companyId > 0 && reportType === "submittals" });
  const { data: payments } = trpc.payments.list.useQuery({ companyId, projectId: projectId ? parseInt(projectId) : undefined }, { enabled: companyId > 0 && reportType === "payments" });

  const statusData = useMemo(() => (stats?.statusBreakdown || []).map(s => ({ name: s.status.replace(/_/g, " "), value: s.count, fill: STATUS_COLORS[s.status] || "#6B7280" })), [stats]);
  const stageData = useMemo(() => (stats?.stageBreakdown || []).map(s => ({ name: s.stage.replace(/_/g, " "), value: s.count })), [stats]);

  const exportCSV = (filename: string, rows: string[][]) => {
    const csv = rows.map(r => r.map(c => `"${c}"`).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = filename; a.click();
    URL.revokeObjectURL(url);
  };

  const exportProjectSummary = () => {
    if (!projects) return;
    const rows = [
      ["Project Code", "Project Name", "Client", "Location", "Contract Value", "Status", "Stage"],
      ...projects.map(p => [p.projectCode, p.name, p.client, p.location || "", p.contractValue || "0", p.status, p.currentStage]),
    ];
    exportCSV("project_summary.csv", rows);
  };

  const exportSubmittalLog = () => {
    if (!submittals) return;
    const rows = [
      ["Title", "Number", "Submitted By", "Submitted Date", "Status", "Comments"],
      ...submittals.map(s => [s.title, s.submittalNumber || "", s.submittedBy || "", s.submittedDate ? new Date(s.submittedDate).toLocaleDateString() : "", s.replyStatus, s.comments || ""]),
    ];
    exportCSV("submittal_log.csv", rows);
  };

  const exportPaymentReport = () => {
    if (!payments) return;
    const rows = [
      ["Certificate #", "Submitted", "Approved", "Received", "Pending", "Status"],
      ...payments.map(p => [p.certificateNumber, p.submittedAmount || "0", p.approvedAmount || "0", p.receivedAmount || "0", p.pendingAmount || "0", p.paymentStatus]),
    ];
    exportCSV("payment_report.csv", rows);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Reports</h2><p className="text-sm text-muted-foreground">Generate and export project reports</p></div>
      </div>

      <div className="flex gap-3">
        <Select value={reportType} onValueChange={setReportType}>
          <SelectTrigger className="w-56 bg-white/5 border-white/10"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="summary">Project Summary</SelectItem>
            <SelectItem value="submittals">Submittal Log</SelectItem>
            <SelectItem value="payments">Payment Report</SelectItem>
            <SelectItem value="quantities">Quantity Progress</SelectItem>
          </SelectContent>
        </Select>
        <Select value={projectId} onValueChange={setProjectId}>
          <SelectTrigger className="w-56 bg-white/5 border-white/10"><SelectValue placeholder="All Projects" /></SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Projects</SelectItem>
            {(projects || []).map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}
          </SelectContent>
        </Select>
        {reportType === "summary" && <Button variant="outline" className="border-white/10 gap-2" onClick={exportProjectSummary}><Download className="w-4 h-4" /> Export CSV</Button>}
        {reportType === "submittals" && <Button variant="outline" className="border-white/10 gap-2" onClick={exportSubmittalLog}><Download className="w-4 h-4" /> Export CSV</Button>}
        {reportType === "payments" && <Button variant="outline" className="border-white/10 gap-2" onClick={exportPaymentReport}><Download className="w-4 h-4" /> Export CSV</Button>}
      </div>

      {reportType === "summary" && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div className="glass-card p-5">
              <h3 className="text-sm font-semibold mb-4">Projects by Status</h3>
              <div className="h-64"><ResponsiveContainer width="100%" height="100%"><PieChart><Pie data={statusData} cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={2} dataKey="value">{statusData.map((e, i) => <Cell key={i} fill={e.fill} />)}</Pie><Tooltip contentStyle={{ background: "#1a1a1a", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} /></PieChart></ResponsiveContainer></div>
            </div>
            <div className="glass-card p-5">
              <h3 className="text-sm font-semibold mb-4">Projects by Stage</h3>
              <div className="h-64"><ResponsiveContainer width="100%" height="100%"><BarChart data={stageData}><CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" /><XAxis dataKey="name" tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} /><YAxis tick={{ fill: "#9CA3AF", fontSize: 11 }} axisLine={false} tickLine={false} /><Tooltip contentStyle={{ background: "#1a1a1a", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", fontSize: "12px" }} /><Bar dataKey="value" fill="#D97706" radius={[4, 4, 0, 0]} /></BarChart></ResponsiveContainer></div>
            </div>
          </div>
          <div className="glass-card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-white/5 text-muted-foreground text-xs uppercase"><tr><th className="text-left p-3">Project</th><th className="text-left p-3">Client</th><th className="text-right p-3">Contract Value</th><th className="text-left p-3">Status</th><th className="text-left p-3">Stage</th></tr></thead>
              <tbody className="divide-y divide-white/5">{(projects || []).map(p => (
                <tr key={p.id} className="hover:bg-white/[0.02]"><td className="p-3 font-medium">{p.name}</td><td className="p-3 text-muted-foreground text-xs">{p.client}</td><td className="p-3 text-right font-mono-metrics">${parseFloat(p.contractValue || "0").toLocaleString()}</td><td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ background: `${STATUS_COLORS[p.status]}20`, color: STATUS_COLORS[p.status] }}>{p.status.replace(/_/g, " ")}</span></td><td className="p-3 text-xs text-muted-foreground">{p.currentStage.replace(/_/g, " ")}</td></tr>
              ))}</tbody>
            </table>
          </div>
        </div>
      )}

      {reportType === "submittals" && (
        <div className="glass-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-white/5 text-muted-foreground text-xs uppercase"><tr><th className="text-left p-3">Title</th><th className="text-left p-3">Number</th><th className="text-left p-3">Submitted By</th><th className="text-left p-3">Date</th><th className="text-left p-3">Status</th><th className="text-left p-3">Comments</th></tr></thead>
            <tbody className="divide-y divide-white/5">{(submittals || []).map(s => (
              <tr key={s.id} className="hover:bg-white/[0.02]"><td className="p-3 font-medium">{s.title}</td><td className="p-3 text-xs text-muted-foreground">{s.submittalNumber || "—"}</td><td className="p-3 text-xs text-muted-foreground">{s.submittedBy || "—"}</td><td className="p-3 text-xs text-muted-foreground">{s.submittedDate ? new Date(s.submittedDate).toLocaleDateString() : "—"}</td><td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ background: `${STATUS_COLORS[s.replyStatus] || "#6B7280"}20`, color: STATUS_COLORS[s.replyStatus] || "#6B7280" }}>{s.replyStatus.replace(/_/g, " ")}</span></td><td className="p-3 text-xs text-muted-foreground max-w-xs truncate">{s.comments || "—"}</td></tr>
            ))}</tbody>
          </table>
        </div>
      )}

      {reportType === "payments" && (
        <div className="glass-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-white/5 text-muted-foreground text-xs uppercase"><tr><th className="text-left p-3">Certificate #</th><th className="text-right p-3">Submitted</th><th className="text-right p-3">Approved</th><th className="text-right p-3">Received</th><th className="text-right p-3">Pending</th><th className="text-left p-3">Status</th></tr></thead>
            <tbody className="divide-y divide-white/5">{(payments || []).map(p => (
              <tr key={p.id} className="hover:bg-white/[0.02]"><td className="p-3 font-medium">{p.certificateNumber}</td><td className="p-3 text-right font-mono-metrics">${parseFloat(p.submittedAmount || "0").toLocaleString()}</td><td className="p-3 text-right font-mono-metrics">${parseFloat(p.approvedAmount || "0").toLocaleString()}</td><td className="p-3 text-right font-mono-metrics text-emerald-500">${parseFloat(p.receivedAmount || "0").toLocaleString()}</td><td className="p-3 text-right font-mono-metrics text-amber-500">${parseFloat(p.pendingAmount || "0").toLocaleString()}</td><td className="p-3"><span className="px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ background: `${STATUS_COLORS[p.paymentStatus] || "#6B7280"}20`, color: STATUS_COLORS[p.paymentStatus] || "#6B7280" }}>{p.paymentStatus.replace(/_/g, " ")}</span></td></tr>
            ))}</tbody>
          </table>
        </div>
      )}

      {reportType === "quantities" && (
        <div className="glass-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-white/5 text-muted-foreground text-xs uppercase"><tr><th className="text-left p-3">Item</th><th className="text-left p-3">Category</th><th className="text-right p-3">Contract</th><th className="text-right p-3">Shop Drw</th><th className="text-right p-3">Fabricated</th><th className="text-right p-3">Delivered</th><th className="text-right p-3">Installed</th></tr></thead>
            <tbody className="divide-y divide-white/5">{(projectItems || []).map(i => (
              <tr key={i.id} className="hover:bg-white/[0.02]"><td className="p-3 font-medium">{i.itemName}</td><td className="p-3 text-xs text-muted-foreground">{i.itemCategory.replace(/_/g, " ")}</td><td className="p-3 text-right font-mono-metrics">{i.contractQuantity || "—"}</td><td className="p-3 text-right font-mono-metrics">{i.shopDrawingApprovedQty || "—"}</td><td className="p-3 text-right font-mono-metrics">{i.fabricatedQuantity || "—"}</td><td className="p-3 text-right font-mono-metrics">{i.deliveredToSite || "—"}</td><td className="p-3 text-right font-mono-metrics">{i.installedQuantity || "—"}</td></tr>
            ))}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}
