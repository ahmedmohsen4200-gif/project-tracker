import { useState } from "react";
import { useNavigate } from "react-router";
import { trpc } from "@/providers/trpc";
import { Building2, Plus, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function CompanySelect() {
  const navigate = useNavigate();
  const { data: companies, isLoading } = trpc.companies.list.useQuery();
  const [isOpen, setIsOpen] = useState(false);
  const utils = trpc.useUtils();
  const createMutation = trpc.companies.create.useMutation({
    onSuccess: (data) => {
      utils.companies.list.invalidate();
      if (data?.id) {
        localStorage.setItem("pl_company_id", data.id.toString());
        navigate("/");
      }
      setIsOpen(false);
    },
  });

  const selectCompany = (id: number) => {
    localStorage.setItem("pl_company_id", id.toString());
    window.location.href = "/";
  };

  const handleCreate = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    createMutation.mutate({
      name: fd.get("name") as string,
      slug: (fd.get("name") as string).toLowerCase().replace(/\s+/g, "-"),
      contactEmail: fd.get("contactEmail") as string || undefined,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#050505] relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-amber-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-amber-500/3 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-lg relative z-10">
        <div className="text-center mb-8">
          <img src="/logo.png" alt="Project Line" className="h-16 w-16 mx-auto mb-4" />
          <h1 className="text-2xl font-bold">Select Workspace</h1>
          <p className="text-sm text-muted-foreground mt-1">Choose a company workspace to continue</p>
        </div>

        <div className="space-y-3">
          {isLoading && <div className="text-center text-muted-foreground py-8">Loading workspaces...</div>}

          {(companies || []).map(c => (
            <button
              key={c.id}
              onClick={() => selectCompany(c.id)}
              className="w-full glass-card p-4 flex items-center gap-4 hover:bg-white/[0.06] transition-all group text-left"
            >
              <div className="w-12 h-12 rounded-xl flex items-center justify-center" style={{ background: `${c.themeColor || "#D97706"}20` }}>
                <Building2 className="w-6 h-6" style={{ color: c.themeColor || "#D97706" }} />
              </div>
              <div className="flex-1">
                <div className="font-medium">{c.name}</div>
                <div className="text-xs text-muted-foreground">{c.contactEmail || "No contact email"}</div>
              </div>
              <ArrowRight className="w-5 h-5 text-muted-foreground group-hover:text-amber-500 transition-colors" />
            </button>
          ))}

          {(companies || []).length === 0 && !isLoading && (
            <div className="text-center py-8 text-muted-foreground">
              <Building2 className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
              <p className="mb-4">No workspaces yet. Create your first workspace to get started.</p>
            </div>
          )}

          <Dialog open={isOpen} onOpenChange={setIsOpen}>
            <DialogTrigger asChild>
              <button className="w-full glass-card p-4 flex items-center gap-4 hover:bg-white/[0.06] transition-all border-dashed border-2 border-white/10 hover:border-amber-500/30 text-left">
                <div className="w-12 h-12 rounded-xl bg-white/5 flex items-center justify-center">
                  <Plus className="w-6 h-6 text-muted-foreground" />
                </div>
                <div>
                  <div className="font-medium text-muted-foreground">Create New Workspace</div>
                  <div className="text-xs text-muted-foreground/60">Set up a new company workspace</div>
                </div>
              </button>
            </DialogTrigger>
            <DialogContent className="bg-[#0F0F0F] border-white/10">
              <DialogHeader><DialogTitle>Create New Workspace</DialogTitle></DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="space-y-2"><Label>Company Name *</Label><Input name="name" placeholder="WEGE Metal Company" required className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Contact Email</Label><Input name="contactEmail" type="email" placeholder="admin@company.com" className="bg-white/5 border-white/10" /></div>
                <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Creating..." : "Create Workspace"}
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}
