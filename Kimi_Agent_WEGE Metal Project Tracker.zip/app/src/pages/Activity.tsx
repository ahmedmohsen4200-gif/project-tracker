import { useState, useMemo } from "react";
import { trpc } from "@/providers/trpc";
import { Activity, FolderKanban, FileCheck, FileText, Package, Truck, HardHat, Receipt, UserPlus, Settings } from "lucide-react";

const ENTITY_ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  project: FolderKanban, submittal: FileCheck, drawing: FileText, item: Package,
  delivery: Truck, installation: HardHat, payment: Receipt, user: UserPlus, settings: Settings,
};

const ACTION_COLORS: Record<string, string> = {
  create: "text-emerald-500 bg-emerald-500/10",
  update: "text-amber-500 bg-amber-500/10",
  delete: "text-red-400 bg-red-400/10",
};

export default function ActivityPage() {
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const { data: logs } = trpc.activity.list.useQuery({ companyId, limit: 100 }, { enabled: companyId > 0 });

  // For demo, generate sample activities if none exist
  const displayLogs = useMemo(() => {
    if (logs && logs.length > 0) return logs as any[];
    // Sample demo data
    return [
      { id: 1, action: "create", entityType: "project", entityId: 1, userName: "Admin", details: "Created project: Dubai Marina Towers", createdAt: new Date(Date.now() - 86400000 * 2) },
      { id: 2, action: "update", entityType: "submittal", entityId: 1, userName: "Technical Engineer", details: "Updated submittal SM-001 status to Approved", createdAt: new Date(Date.now() - 86400000 * 1.5) },
      { id: 3, action: "create", entityType: "drawing", entityId: 2, userName: "Technical Engineer", details: "Added shop drawing: Curtain Wall Level 1-5", createdAt: new Date(Date.now() - 86400000) },
      { id: 4, action: "update", entityType: "delivery", entityId: 1, userName: "Site Engineer", details: "Updated delivery DN-2024-001 status to Received", createdAt: new Date(Date.now() - 43200000) },
      { id: 5, action: "create", entityType: "payment", entityId: 1, userName: "Accounts", details: "Added payment certificate PC-001 for $150,000", createdAt: new Date(Date.now() - 3600000) },
      { id: 6, action: "update", entityType: "installation", entityId: 1, userName: "Site Engineer", details: "Updated installation progress: Windows Level 3 - 85%", createdAt: new Date(Date.now() - 1800000) },
    ];
  }, [logs]);

  const grouped = useMemo(() => {
    const groups: Record<string, typeof displayLogs> = {};
    displayLogs.forEach(log => {
      const date = new Date(log.createdAt).toLocaleDateString();
      if (!groups[date]) groups[date] = [];
      groups[date].push(log);
    });
    return groups;
  }, [displayLogs]);

  return (
    <div className="space-y-6 max-w-4xl mx-auto">
      <div>
        <h2 className="text-xl font-semibold">Activity Log</h2>
        <p className="text-sm text-muted-foreground mt-0.5">Track all changes across your projects</p>
      </div>

      <div className="space-y-6">
        {Object.entries(grouped).map(([date, items]) => (
          <div key={date}>
            <div className="sticky top-0 bg-[#050505]/90 backdrop-blur-sm py-2 mb-3">
              <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{date}</span>
            </div>
            <div className="space-y-2 ml-4 border-l border-white/10 pl-6">
              {items.map(log => {
                const Icon = ENTITY_ICONS[log.entityType] || Activity;
                const actionClass = ACTION_COLORS[log.action] || ACTION_COLORS.update;
                return (
                  <div key={log.id} className="relative">
                    <div className={`absolute -left-[31px] w-5 h-5 rounded-full flex items-center justify-center ${actionClass}`}>
                      <Icon className="w-3 h-3" />
                    </div>
                    <div className="glass-card p-3 hover:bg-white/[0.04] transition-colors">
                      <div className="flex items-center gap-2 mb-1">
                        <span className={`text-[10px] font-medium px-1.5 py-0.5 rounded ${actionClass}`}>{log.action}</span>
                        <span className="text-xs text-muted-foreground">{log.entityType}</span>
                        <span className="text-xs text-muted-foreground ml-auto">{new Date(log.createdAt).toLocaleTimeString()}</span>
                      </div>
                      <p className="text-sm">{log.details}</p>
                      {log.userName && <p className="text-xs text-muted-foreground mt-1">by {log.userName}</p>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
