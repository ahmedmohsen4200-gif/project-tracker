import { useState, useMemo } from "react";
import { useSearchParams } from "react-router";
import { trpc } from "@/providers/trpc";
import { Plus, Pencil, Trash2, Search, Truck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

const DELIVERY_STATUS = ["pending", "in_transit", "delivered", "received", "partial", "rejected"];
const STATUS_COLORS: Record<string, string> = { pending: "#F59E0B", in_transit: "#3B82F6", delivered: "#8B5CF6", received: "#22C55E", partial: "#F97316", rejected: "#EF4444" };

export default function DeliveriesPage() {
  const [searchParams] = useSearchParams();
  const projectIdParam = searchParams.get("project");
  const [companyId] = useState(() => parseInt(localStorage.getItem("pl_company_id") || "0"));
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [editId, setEditId] = useState<number | null>(null);
  const utils = trpc.useUtils();

  const { data } = trpc.deliveries.list.useQuery({ companyId, projectId: projectIdParam ? parseInt(projectIdParam) : undefined });
  const createMut = trpc.deliveries.create.useMutation({ onSuccess: () => { utils.deliveries.list.invalidate(); setIsOpen(false); } });
  const updateMut = trpc.deliveries.update.useMutation({ onSuccess: () => { utils.deliveries.list.invalidate(); setEditId(null); } });
  const deleteMut = trpc.deliveries.delete.useMutation({ onSuccess: () => utils.deliveries.list.invalidate() });
  const projects = trpc.projects.list.useQuery({ companyId });
  const projectMap = useMemo(() => { const m: Record<number, string> = {}; (projects.data || []).forEach(p => m[p.id] = p.name); return m; }, [projects.data]);
  const filtered = useMemo(() => !data ? [] : search ? data.filter(d => d.materialDescription.toLowerCase().includes(search.toLowerCase())) : data, [data, search]);
  const editing = editId ? data?.find(d => d.id === editId) : null;

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const payload: any = {
      projectId: parseInt(fd.get("projectId") as string), companyId,
      deliveryNoteNumber: fd.get("deliveryNoteNumber") || undefined,
      materialDescription: fd.get("materialDescription"),
      deliveredQuantity: fd.get("deliveredQuantity") || undefined,
      receivedQuantity: fd.get("receivedQuantity") || undefined,
      deliveryDate: fd.get("deliveryDate") || undefined,
      receivedBy: fd.get("receivedBy") || undefined,
      deliveryStatus: fd.get("deliveryStatus") || "pending",
      notes: fd.get("notes") || undefined,
    };
    if (editId) { payload.id = editId; delete payload.projectId; delete payload.companyId; updateMut.mutate(payload); }
    else createMut.mutate(payload);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between">
        <div><h2 className="text-xl font-semibold">Delivery Tracking</h2><p className="text-sm text-muted-foreground">Track material deliveries to site</p></div>
        <Dialog open={isOpen} onOpenChange={(v) => { setIsOpen(v); setEditId(null); }}>
          <DialogTrigger asChild><Button className="bg-amber-500 hover:bg-amber-600 text-white gap-2"><Plus className="w-4 h-4" /> Add Delivery</Button></DialogTrigger>
          <DialogContent className="max-w-xl bg-[#0F0F0F] border-white/10 max-h-[90vh] overflow-y-auto">
            <DialogHeader><DialogTitle>{editId ? "Edit" : "Add"} Delivery</DialogTitle></DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-3">
              <div className="space-y-2"><Label>Project</Label><Select name="projectId" defaultValue={projectIdParam || editing?.projectId?.toString()}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{(projects.data || []).map(p => <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Delivery Note #</Label><Input name="deliveryNoteNumber" defaultValue={editing?.deliveryNoteNumber || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Delivery Date</Label><Input name="deliveryDate" type="date" defaultValue={editing?.deliveryDate ? new Date(editing.deliveryDate).toISOString().split("T")[0] : ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="space-y-2"><Label>Material Description *</Label><Input name="materialDescription" defaultValue={editing?.materialDescription} required className="bg-white/5 border-white/10" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Delivered Qty</Label><Input name="deliveredQuantity" type="number" step="0.01" defaultValue={editing?.deliveredQuantity || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Received Qty</Label><Input name="receivedQuantity" type="number" step="0.01" defaultValue={editing?.receivedQuantity || ""} className="bg-white/5 border-white/10" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2"><Label>Received By</Label><Input name="receivedBy" defaultValue={editing?.receivedBy || ""} className="bg-white/5 border-white/10" /></div>
                <div className="space-y-2"><Label>Status</Label><Select name="deliveryStatus" defaultValue={editing?.deliveryStatus || "pending"}><SelectTrigger className="bg-white/5 border-white/10"><SelectValue /></SelectTrigger><SelectContent>{DELIVERY_STATUS.map(s => <SelectItem key={s} value={s}>{s.replace(/_/g, " ")}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="space-y-2"><Label>Notes</Label><Textarea name="notes" defaultValue={editing?.notes || ""} className="bg-white/5 border-white/10" /></div>
              <Button type="submit" className="w-full bg-amber-500 hover:bg-amber-600 text-white">{editId ? "Save" : "Create"}</Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>
      <div className="relative max-w-xs"><Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" /><Input placeholder="Search deliveries..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10" /></div>
      <div className="space-y-3">
        {filtered.map(d => (
          <div key={d.id} className="glass-card p-4 hover:bg-white/[0.04] transition-colors">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-blue-500/10 flex items-center justify-center"><Truck className="w-5 h-5 text-blue-500" /></div>
                <div>
                  <div className="font-medium text-sm">{d.materialDescription}</div>
                  <div className="text-xs text-muted-foreground mt-0.5">{projectMap[d.projectId] || "—"} | DN: {d.deliveryNoteNumber || "—"}</div>
                </div>
              </div>
              <span className="px-2 py-0.5 rounded-full text-[10px] font-medium" style={{ background: `${STATUS_COLORS[d.deliveryStatus]}20`, color: STATUS_COLORS[d.deliveryStatus] }}>{d.deliveryStatus.replace(/_/g, " ")}</span>
            </div>
            <div className="grid grid-cols-4 gap-4 mt-3 pt-3 border-t border-white/5 text-xs">
              <div><div className="text-muted-foreground">Delivered</div><div className="font-mono-metrics font-medium">{d.deliveredQuantity || "—"}</div></div>
              <div><div className="text-muted-foreground">Received</div><div className="font-mono-metrics font-medium">{d.receivedQuantity || "—"}</div></div>
              <div><div className="text-muted-foreground">Date</div><div className="text-muted-foreground">{d.deliveryDate ? new Date(d.deliveryDate).toLocaleDateString() : "—"}</div></div>
              <div><div className="text-muted-foreground">Received By</div><div className="text-muted-foreground">{d.receivedBy || "—"}</div></div>
            </div>
            <div className="flex justify-end gap-1 mt-2"><Button variant="ghost" size="icon" className="h-7 w-7" onClick={() => { setEditId(d.id); setIsOpen(true); }}><Pencil className="w-3.5 h-3.5" /></Button><Button variant="ghost" size="icon" className="h-7 w-7 text-red-400" onClick={() => { if (confirm("Delete?")) deleteMut.mutate({ id: d.id }); }}><Trash2 className="w-3.5 h-3.5" /></Button></div>
          </div>
        ))}
        {filtered.length === 0 && <div className="text-center py-12 text-muted-foreground">No deliveries found</div>}
      </div>
    </div>
  );
}
