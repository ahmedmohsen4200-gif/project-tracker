import { Routes, Route, Navigate } from 'react-router'
import { useAuth } from './hooks/useAuth'
import AppLayout from './components/AppLayout'
import Login from './pages/Login'
import CompanySelect from './pages/CompanySelect'
import Dashboard from './pages/Dashboard'
import ProjectsPage from './pages/Projects'
import SubmittalsPage from './pages/Submittals'
import ShopDrawingsPage from './pages/ShopDrawings'
import QuantitiesPage from './pages/Quantities'
import DeliveriesPage from './pages/Deliveries'
import InstallationPage from './pages/Installation'
import PaymentsPage from './pages/Payments'
import ReportsPage from './pages/Reports'
import UsersPage from './pages/Users'
import SettingsPage from './pages/SettingsPage'
import ActivityPage from './pages/Activity'
import NotificationsPage from './pages/Notifications'
import NotFound from './pages/NotFound'

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth()

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050505]">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  if (!user) {
    return <Navigate to="/login" replace />
  }

  // Check if company is selected
  const companyId = localStorage.getItem("pl_company_id")
  if (!companyId && window.location.pathname !== "/select-company") {
    return <Navigate to="/select-company" replace />
  }

  return <AppLayout>{children}</AppLayout>
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/select-company" element={
        <AuthGuard><CompanySelect /></AuthGuard>
      } />
      <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="/projects" element={<ProtectedRoute><ProjectsPage /></ProtectedRoute>} />
      <Route path="/projects/:id" element={<ProtectedRoute><ProjectsPage /></ProtectedRoute>} />
      <Route path="/submittals" element={<ProtectedRoute><SubmittalsPage /></ProtectedRoute>} />
      <Route path="/drawings" element={<ProtectedRoute><ShopDrawingsPage /></ProtectedRoute>} />
      <Route path="/quantities" element={<ProtectedRoute><QuantitiesPage /></ProtectedRoute>} />
      <Route path="/deliveries" element={<ProtectedRoute><DeliveriesPage /></ProtectedRoute>} />
      <Route path="/installation" element={<ProtectedRoute><InstallationPage /></ProtectedRoute>} />
      <Route path="/payments" element={<ProtectedRoute><PaymentsPage /></ProtectedRoute>} />
      <Route path="/reports" element={<ProtectedRoute><ReportsPage /></ProtectedRoute>} />
      <Route path="/users" element={<ProtectedRoute><UsersPage /></ProtectedRoute>} />
      <Route path="/settings" element={<ProtectedRoute><SettingsPage /></ProtectedRoute>} />
      <Route path="/activity" element={<ProtectedRoute><ActivityPage /></ProtectedRoute>} />
      <Route path="/notifications" element={<ProtectedRoute><NotificationsPage /></ProtectedRoute>} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}

function AuthGuard({ children }: { children: React.ReactNode }) {
  const { user, isLoading } = useAuth()
  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050505]">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }
  if (!user) return <Navigate to="/login" replace />
  return <>{children}</>
}
