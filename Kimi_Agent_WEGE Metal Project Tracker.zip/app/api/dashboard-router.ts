import { z } from "zod";
import { eq, and, count, sum } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { projects, submittals, shopDrawings, paymentCertificates } from "@db/schema";

export const dashboardRouter = createRouter({
  stats: publicQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return null;
      const db = getDb();
      const companyId = input.companyId;

      const [projectCount] = await db.select({ count: count() }).from(projects)
        .where(eq(projects.companyId, companyId));

      const [contractValue] = await db.select({
        total: sum(projects.contractValue),
      }).from(projects).where(eq(projects.companyId, companyId));

      const statusCounts = await db.select({
        status: projects.status,
        count: count(),
      }).from(projects).where(eq(projects.companyId, companyId))
        .groupBy(projects.status);

      const stageCounts = await db.select({
        stage: projects.currentStage,
        count: count(),
      }).from(projects).where(eq(projects.companyId, companyId))
        .groupBy(projects.currentStage);

      const [pendingSubmittals] = await db.select({ count: count() }).from(submittals)
        .where(and(
          eq(submittals.companyId, companyId),
          eq(submittals.replyStatus, "pending"),
        ));

      const [pendingDrawings] = await db.select({ count: count() }).from(shopDrawings)
        .where(and(
          eq(shopDrawings.companyId, companyId),
          eq(shopDrawings.approvalStatus, "pending"),
        ));

      const [paymentStats] = await db.select({
        totalSubmitted: sum(paymentCertificates.submittedAmount),
        totalApproved: sum(paymentCertificates.approvedAmount),
        totalReceived: sum(paymentCertificates.receivedAmount),
        totalPending: sum(paymentCertificates.pendingAmount),
      }).from(paymentCertificates)
        .where(eq(paymentCertificates.companyId, companyId));

      return {
        totalProjects: projectCount?.count ?? 0,
        totalContractValue: contractValue?.total ?? "0",
        statusBreakdown: statusCounts,
        stageBreakdown: stageCounts,
        pendingSubmittals: pendingSubmittals?.count ?? 0,
        pendingDrawings: pendingDrawings?.count ?? 0,
        paymentStats: {
          totalSubmitted: paymentStats?.totalSubmitted ?? "0",
          totalApproved: paymentStats?.totalApproved ?? "0",
          totalReceived: paymentStats?.totalReceived ?? "0",
          totalPending: paymentStats?.totalPending ?? "0",
        },
      };
    }),
});
