import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { companies, companyMembers } from "@db/schema";

export const companiesRouter = createRouter({
  list: publicQuery.query(async ({ ctx }) => {
    if (!ctx.user) return [];
    const db = getDb();
    const members = await db.select().from(companyMembers)
      .where(eq(companyMembers.userId, ctx.user.id));
    if (members.length === 0) return [];
    const companyIds = members.map(m => m.companyId);
    const result = await db.select().from(companies)
      .where(and(...companyIds.map(id => eq(companies.id, id))));
    return result;
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return null;
      const db = getDb();
      const [company] = await db.select().from(companies)
        .where(eq(companies.id, input.id));
      return company ?? null;
    }),

  create: publicQuery
    .input(z.object({
      name: z.string().min(1),
      slug: z.string().min(1),
      logo: z.string().optional(),
      contactEmail: z.string().email().optional(),
      contactPhone: z.string().optional(),
      address: z.string().optional(),
      website: z.string().optional(),
      themeColor: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Authentication required");
      const db = getDb();
      const [company] = await db.insert(companies).values({
        ...input,
        createdById: ctx.user.id,
        isActive: true,
      }).$returningId();
      // Add creator as owner
      await db.insert(companyMembers).values({
        companyId: company.id,
        userId: ctx.user.id,
        companyRole: "owner",
        isActive: true,
      });
      return { id: company.id, ...input };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      name: z.string().optional(),
      logo: z.string().optional(),
      contactEmail: z.string().email().optional(),
      contactPhone: z.string().optional(),
      address: z.string().optional(),
      website: z.string().optional(),
      themeColor: z.string().optional(),
      isActive: z.boolean().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Authentication required");
      const db = getDb();
      const { id, ...data } = input;
      await db.update(companies).set(data).where(eq(companies.id, id));
      return { success: true };
    }),

  getMembers: publicQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      return db.select().from(companyMembers)
        .where(eq(companyMembers.companyId, input.companyId));
    }),

  addMember: publicQuery
    .input(z.object({
      companyId: z.number(),
      userId: z.number(),
      companyRole: z.enum([
        "admin", "estimation_engineer", "technical_engineer",
        "procurement_fabrication", "site_engineer", "accounts_finance",
      ]),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Authentication required");
      const db = getDb();
      const [member] = await db.insert(companyMembers).values({
        ...input,
        isActive: true,
      }).$returningId();
      return { id: member.id };
    }),

  removeMember: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Authentication required");
      const db = getDb();
      await db.delete(companyMembers).where(eq(companyMembers.id, input.id));
      return { success: true };
    }),

  updateMemberRole: publicQuery
    .input(z.object({
      id: z.number(),
      companyRole: z.enum([
        "admin", "estimation_engineer", "technical_engineer",
        "procurement_fabrication", "site_engineer", "accounts_finance",
      ]),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Authentication required");
      const db = getDb();
      await db.update(companyMembers)
        .set({ companyRole: input.companyRole })
        .where(eq(companyMembers.id, input.id));
      return { success: true };
    }),
});
