import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { submittals } from "@db/schema";

export const submittalsRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number(), projectId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      const conditions = [eq(submittals.companyId, input.companyId)];
      if (input.projectId) conditions.push(eq(submittals.projectId, input.projectId));
      return db.select().from(submittals)
        .where(and(...conditions))
        .orderBy(desc(submittals.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      projectId: z.number(),
      companyId: z.number(),
      title: z.string().min(1),
      submittalNumber: z.string().optional(),
      submittedBy: z.string().optional(),
      submittedDate: z.string().optional(),
      submittedTo: z.string().optional(),
      consultantReplyDate: z.string().optional(),
      replyStatus: z.string().optional(),
      comments: z.string().optional(),
      revisionNumber: z.string().optional(),
      attachmentLink: z.string().optional(),
      nextActionRequired: z.string().optional(),
      responsiblePerson: z.string().optional(),
      dueDate: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data: any = { ...input };
      if (input.submittedDate) data.submittedDate = new Date(input.submittedDate);
      if (input.consultantReplyDate) data.consultantReplyDate = new Date(input.consultantReplyDate);
      if (input.dueDate) data.dueDate = new Date(input.dueDate);
      const [result] = await db.insert(submittals).values(data).$returningId();
      return { id: result.id, ...data };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      title: z.string().optional(),
      submittalNumber: z.string().optional(),
      submittedBy: z.string().optional(),
      submittedDate: z.string().optional(),
      submittedTo: z.string().optional(),
      consultantReplyDate: z.string().optional(),
      replyStatus: z.string().optional(),
      comments: z.string().optional(),
      revisionNumber: z.string().optional(),
      attachmentLink: z.string().optional(),
      nextActionRequired: z.string().optional(),
      responsiblePerson: z.string().optional(),
      dueDate: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const { id, ...raw } = input;
      const data: any = { ...raw };
      if (raw.submittedDate) data.submittedDate = new Date(raw.submittedDate);
      if (raw.consultantReplyDate) data.consultantReplyDate = new Date(raw.consultantReplyDate);
      if (raw.dueDate) data.dueDate = new Date(raw.dueDate);
      await db.update(submittals).set(data).where(eq(submittals.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(submittals).where(eq(submittals.id, input.id));
      return { success: true };
    }),
});
