import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { paymentCertificates } from "@db/schema";

export const paymentsRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number(), projectId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      const conditions = [eq(paymentCertificates.companyId, input.companyId)];
      if (input.projectId) conditions.push(eq(paymentCertificates.projectId, input.projectId));
      return db.select().from(paymentCertificates).where(and(...conditions)).orderBy(desc(paymentCertificates.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      projectId: z.number(), companyId: z.number(),
      certificateNumber: z.string().min(1),
      submittedAmount: z.string().optional(), submissionDate: z.string().optional(),
      approvedAmount: z.string().optional(), approvalDate: z.string().optional(),
      receivedAmount: z.string().optional(), paymentReceivedDate: z.string().optional(),
      pendingAmount: z.string().optional(), retentionAmount: z.string().optional(),
      vatAmount: z.string().optional(), totalCollected: z.string().optional(),
      remainingBalance: z.string().optional(), paymentStatus: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data: any = { ...input };
      if (input.submissionDate) data.submissionDate = new Date(input.submissionDate);
      if (input.approvalDate) data.approvalDate = new Date(input.approvalDate);
      if (input.paymentReceivedDate) data.paymentReceivedDate = new Date(input.paymentReceivedDate);
      const [r] = await db.insert(paymentCertificates).values(data).$returningId();
      return { id: r.id };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(), certificateNumber: z.string().optional(),
      submittedAmount: z.string().optional(), submissionDate: z.string().optional(),
      approvedAmount: z.string().optional(), approvalDate: z.string().optional(),
      receivedAmount: z.string().optional(), paymentReceivedDate: z.string().optional(),
      pendingAmount: z.string().optional(), retentionAmount: z.string().optional(),
      vatAmount: z.string().optional(), totalCollected: z.string().optional(),
      remainingBalance: z.string().optional(), paymentStatus: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const { id, ...raw } = input;
      const data: any = { ...raw };
      if (raw.submissionDate) data.submissionDate = new Date(raw.submissionDate);
      if (raw.approvalDate) data.approvalDate = new Date(raw.approvalDate);
      if (raw.paymentReceivedDate) data.paymentReceivedDate = new Date(raw.paymentReceivedDate);
      await db.update(paymentCertificates).set(data).where(eq(paymentCertificates.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(paymentCertificates).where(eq(paymentCertificates.id, input.id));
      return { success: true };
    }),
});
