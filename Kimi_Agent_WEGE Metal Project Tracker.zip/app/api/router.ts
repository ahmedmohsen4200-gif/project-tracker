import { authRouter } from "./auth-router";
import { companiesRouter } from "./companies-router";
import { projectsRouter } from "./projects-router";
import { dashboardRouter } from "./dashboard-router";
import { submittalsRouter } from "./submittals-router";
import { drawingsRouter } from "./drawings-router";
import { itemsRouter } from "./items-router";
import { deliveriesRouter } from "./deliveries-router";
import { installationsRouter } from "./installations-router";
import { paymentsRouter } from "./payments-router";
import { activityRouter } from "./activity-router";
import { notificationsRouter } from "./notifications-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  companies: companiesRouter,
  projects: projectsRouter,
  dashboard: dashboardRouter,
  submittals: submittalsRouter,
  drawings: drawingsRouter,
  items: itemsRouter,
  deliveries: deliveriesRouter,
  installations: installationsRouter,
  payments: paymentsRouter,
  activity: activityRouter,
  notifications: notificationsRouter,
});

export type AppRouter = typeof appRouter;
