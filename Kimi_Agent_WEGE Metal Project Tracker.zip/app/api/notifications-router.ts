import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { notifications } from "@db/schema";

export const notificationsRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      return db.select().from(notifications)
        .where(and(
          eq(notifications.companyId, input.companyId),
          eq(notifications.userId, ctx.user.id),
        ))
        .orderBy(desc(notifications.createdAt))
        .limit(50);
    }),

  unreadCount: publicQuery
    .input(z.object({ companyId: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return 0;
      const db = getDb();
      const result = await db.select().from(notifications)
        .where(and(
          eq(notifications.companyId, input.companyId),
          eq(notifications.userId, ctx.user.id),
          eq(notifications.isRead, false),
        ));
      return result.length;
    }),

  markRead: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.update(notifications)
        .set({ isRead: true })
        .where(eq(notifications.id, input.id));
      return { success: true };
    }),

  markAllRead: publicQuery
    .input(z.object({ companyId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.update(notifications)
        .set({ isRead: true })
        .where(and(
          eq(notifications.companyId, input.companyId),
          eq(notifications.userId, ctx.user.id),
        ));
      return { success: true };
    }),

  create: publicQuery
    .input(z.object({
      companyId: z.number(), userId: z.number(),
      title: z.string().min(1), message: z.string().min(1),
      type: z.string().optional(),
      relatedEntityType: z.string().optional(),
      relatedEntityId: z.number().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data: any = { ...input };
      if (input.type) data.type = input.type;
      const [r] = await db.insert(notifications).values(data).$returningId();
      return { id: r.id };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(notifications).where(eq(notifications.id, input.id));
      return { success: true };
    }),
});
