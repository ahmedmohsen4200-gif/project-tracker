import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { deliveries } from "@db/schema";

export const deliveriesRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number(), projectId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      const conditions = [eq(deliveries.companyId, input.companyId)];
      if (input.projectId) conditions.push(eq(deliveries.projectId, input.projectId));
      return db.select().from(deliveries).where(and(...conditions)).orderBy(desc(deliveries.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      projectId: z.number(), companyId: z.number(),
      deliveryNoteNumber: z.string().optional(),
      materialDescription: z.string().min(1),
      deliveredQuantity: z.string().optional(), receivedQuantity: z.string().optional(),
      deliveryDate: z.string().optional(), receivedBy: z.string().optional(),
      deliveryStatus: z.string().optional(), notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data: any = { ...input };
      if (input.deliveryDate) data.deliveryDate = new Date(input.deliveryDate);
      const [r] = await db.insert(deliveries).values(data).$returningId();
      return { id: r.id };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(), deliveryNoteNumber: z.string().optional(),
      materialDescription: z.string().optional(),
      deliveredQuantity: z.string().optional(), receivedQuantity: z.string().optional(),
      deliveryDate: z.string().optional(), receivedBy: z.string().optional(),
      deliveryStatus: z.string().optional(), notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const { id, ...raw } = input;
      const data: any = { ...raw };
      if (raw.deliveryDate) data.deliveryDate = new Date(raw.deliveryDate);
      await db.update(deliveries).set(data).where(eq(deliveries.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(deliveries).where(eq(deliveries.id, input.id));
      return { success: true };
    }),
});
