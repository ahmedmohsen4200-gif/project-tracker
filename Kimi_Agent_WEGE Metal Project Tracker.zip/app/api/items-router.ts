import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { projectItems } from "@db/schema";

export const itemsRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number(), projectId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      const conditions = [eq(projectItems.companyId, input.companyId)];
      if (input.projectId) conditions.push(eq(projectItems.projectId, input.projectId));
      return db.select().from(projectItems)
        .where(and(...conditions))
        .orderBy(desc(projectItems.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      projectId: z.number(), companyId: z.number(), itemName: z.string().min(1),
      itemCategory: z.string().optional(), unit: z.string().optional(),
      contractQuantity: z.string().optional(), notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data: any = { ...input, remainingQuantity: input.contractQuantity || "0" };
      const [r] = await db.insert(projectItems).values(data).$returningId();
      return { id: r.id };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(), itemName: z.string().optional(), itemCategory: z.string().optional(),
      unit: z.string().optional(), contractQuantity: z.string().optional(),
      shopDrawingApprovedQty: z.string().optional(), releasedForFabrication: z.string().optional(),
      fabricatedQuantity: z.string().optional(), deliveredToSite: z.string().optional(),
      receivedBySite: z.string().optional(), installedQuantity: z.string().optional(),
      remainingQuantity: z.string().optional(), notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const { id, ...raw } = input;
      const data: any = { ...raw };
      if (raw.itemCategory) data.itemCategory = raw.itemCategory;
      await db.update(projectItems).set(data).where(eq(projectItems.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(projectItems).where(eq(projectItems.id, input.id));
      return { success: true };
    }),
});
