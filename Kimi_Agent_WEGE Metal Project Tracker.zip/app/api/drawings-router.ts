import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { shopDrawings } from "@db/schema";

export const drawingsRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number(), projectId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      const conditions = [eq(shopDrawings.companyId, input.companyId)];
      if (input.projectId) conditions.push(eq(shopDrawings.projectId, input.projectId));
      return db.select().from(shopDrawings)
        .where(and(...conditions))
        .orderBy(desc(shopDrawings.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      projectId: z.number(), companyId: z.number(),
      title: z.string().min(1), drawingNumber: z.string().optional(),
      revision: z.string().optional(), submittedDate: z.string().optional(),
      consultantReplyDate: z.string().optional(), approvalStatus: z.string().optional(),
      approvedQuantity: z.string().optional(), itemCategory: z.string().optional(),
      attachmentLink: z.string().optional(), notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data: any = { ...input };
      if (input.submittedDate) data.submittedDate = new Date(input.submittedDate);
      if (input.consultantReplyDate) data.consultantReplyDate = new Date(input.consultantReplyDate);
      const [r] = await db.insert(shopDrawings).values(data).$returningId();
      return { id: r.id };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(), title: z.string().optional(), drawingNumber: z.string().optional(),
      revision: z.string().optional(), submittedDate: z.string().optional(),
      consultantReplyDate: z.string().optional(), approvalStatus: z.string().optional(),
      approvedQuantity: z.string().optional(), itemCategory: z.string().optional(),
      attachmentLink: z.string().optional(), notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const { id, ...raw } = input;
      const data: any = { ...raw };
      if (raw.submittedDate) data.submittedDate = new Date(raw.submittedDate);
      if (raw.consultantReplyDate) data.consultantReplyDate = new Date(raw.consultantReplyDate);
      await db.update(shopDrawings).set(data).where(eq(shopDrawings.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(shopDrawings).where(eq(shopDrawings.id, input.id));
      return { success: true };
    }),
});
