import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { activityLogs } from "@db/schema";

export const activityRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number(), limit: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      return db.select().from(activityLogs)
        .where(eq(activityLogs.companyId, input.companyId))
        .orderBy(desc(activityLogs.createdAt))
        .limit(input.limit || 100);
    }),

  create: publicQuery
    .input(z.object({
      companyId: z.number(),
      action: z.string().min(1),
      entityType: z.string().min(1),
      entityId: z.number().optional(),
      details: z.string().optional(),
      userName: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [r] = await db.insert(activityLogs).values({
        ...input,
        userId: ctx.user?.id,
      }).$returningId();
      return { id: r.id };
    }),
});
