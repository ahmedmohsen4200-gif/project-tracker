import { z } from "zod";
import { eq, and, desc, like } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { projects } from "@db/schema";

export const projectsRouter = createRouter({
  list: publicQuery
    .input(z.object({
      companyId: z.number(),
      search: z.string().optional(),
      status: z.string().optional(),
      stage: z.string().optional(),
    }).optional())
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      if (!input) return [];
      const conditions = [eq(projects.companyId, input.companyId)];
      if (input.search) {
        conditions.push(like(projects.name, `%${input.search}%`));
      }
      if (input.status) {
        conditions.push(eq(projects.status, input.status as any));
      }
      if (input.stage) {
        conditions.push(eq(projects.currentStage, input.stage as any));
      }
      return db.select().from(projects)
        .where(and(...conditions))
        .orderBy(desc(projects.createdAt));
    }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return null;
      const db = getDb();
      const [project] = await db.select().from(projects)
        .where(eq(projects.id, input.id));
      return project ?? null;
    }),

  create: publicQuery
    .input(z.object({
      companyId: z.number(),
      projectCode: z.string().min(1),
      name: z.string().min(1),
      client: z.string().min(1),
      consultant: z.string().optional(),
      location: z.string().optional(),
      scopeOfWork: z.string().optional(),
      projectManager: z.string().optional(),
      startDate: z.string().optional(),
      expectedFinishDate: z.string().optional(),
      contractDate: z.string().optional(),
      contractValue: z.string().optional(),
      status: z.string().optional(),
      currentStage: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data = {
        ...input,
        createdById: ctx.user.id,
        contractValue: input.contractValue || "0",
        status: (input.status || "tender") as any,
        currentStage: (input.currentStage || "estimation") as any,
        startDate: input.startDate ? new Date(input.startDate) : null,
        expectedFinishDate: input.expectedFinishDate ? new Date(input.expectedFinishDate) : null,
        contractDate: input.contractDate ? new Date(input.contractDate) : null,
      };
      const [result] = await db.insert(projects).values(data).$returningId();
      return { id: result.id, ...data };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(),
      projectCode: z.string().optional(),
      name: z.string().optional(),
      client: z.string().optional(),
      consultant: z.string().optional(),
      location: z.string().optional(),
      scopeOfWork: z.string().optional(),
      projectManager: z.string().optional(),
      startDate: z.string().optional(),
      expectedFinishDate: z.string().optional(),
      contractDate: z.string().optional(),
      contractValue: z.string().optional(),
      status: z.string().optional(),
      currentStage: z.string().optional(),
      notes: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const { id, ...raw } = input;
      const data: any = { ...raw };
      if (raw.startDate) data.startDate = new Date(raw.startDate);
      if (raw.expectedFinishDate) data.expectedFinishDate = new Date(raw.expectedFinishDate);
      if (raw.contractDate) data.contractDate = new Date(raw.contractDate);
      if (raw.status) data.status = raw.status;
      if (raw.currentStage) data.currentStage = raw.currentStage;
      await db.update(projects).set(data).where(eq(projects.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(projects).where(eq(projects.id, input.id));
      return { success: true };
    }),
});
