import { z } from "zod";
import { eq, and, desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { installations } from "@db/schema";

export const installationsRouter = createRouter({
  list: publicQuery
    .input(z.object({ companyId: z.number(), projectId: z.number().optional() }))
    .query(async ({ ctx, input }) => {
      if (!ctx.user) return [];
      const db = getDb();
      const conditions = [eq(installations.companyId, input.companyId)];
      if (input.projectId) conditions.push(eq(installations.projectId, input.projectId));
      return db.select().from(installations).where(and(...conditions)).orderBy(desc(installations.createdAt));
    }),

  create: publicQuery
    .input(z.object({
      projectId: z.number(), companyId: z.number(), itemName: z.string().min(1),
      installedQuantity: z.string().optional(), installationDate: z.string().optional(),
      areaZone: z.string().optional(), floor: z.string().optional(),
      teamName: z.string().optional(), siteNotes: z.string().optional(),
      remainingQuantity: z.string().optional(), installationPercentage: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const data: any = { ...input };
      if (input.installationDate) data.installationDate = new Date(input.installationDate);
      const [r] = await db.insert(installations).values(data).$returningId();
      return { id: r.id };
    }),

  update: publicQuery
    .input(z.object({
      id: z.number(), itemName: z.string().optional(),
      installedQuantity: z.string().optional(), installationDate: z.string().optional(),
      areaZone: z.string().optional(), floor: z.string().optional(),
      teamName: z.string().optional(), siteNotes: z.string().optional(),
      remainingQuantity: z.string().optional(), installationPercentage: z.string().optional(),
    }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      const { id, ...raw } = input;
      const data: any = { ...raw };
      if (raw.installationDate) data.installationDate = new Date(raw.installationDate);
      await db.update(installations).set(data).where(eq(installations.id, id));
      return { success: true };
    }),

  delete: publicQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      if (!ctx.user) throw new Error("Auth required");
      const db = getDb();
      await db.delete(installations).where(eq(installations.id, input.id));
      return { success: true };
    }),
});
