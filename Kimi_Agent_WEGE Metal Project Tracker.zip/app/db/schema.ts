import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  bigint,
  decimal,
  json,
  boolean,
} from "drizzle-orm/mysql-core";

// ─── Core Users (OAuth) ──────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Companies (Multi-tenant Workspaces) ─────────────────────────
export const companies = mysqlTable("companies", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  logo: text("logo"),
  contactEmail: varchar("contact_email", { length: 320 }),
  contactPhone: varchar("contact_phone", { length: 50 }),
  address: text("address"),
  website: varchar("website", { length: 255 }),
  themeColor: varchar("theme_color", { length: 20 }).default("#D97706"),
  isActive: boolean("is_active").default(true).notNull(),
  createdById: bigint("created_by_id", { mode: "number", unsigned: true }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Company = typeof companies.$inferSelect;

// ─── Company Members (Roles per company) ─────────────────────────
export const companyMembers = mysqlTable("company_members", {
  id: serial("id").primaryKey(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  // Role in the company context
  companyRole: mysqlEnum("company_role", [
    "owner",
    "admin",
    "estimation_engineer",
    "technical_engineer",
    "procurement_fabrication",
    "site_engineer",
    "accounts_finance",
  ]).notNull(),
  isActive: boolean("is_active").default(true).notNull(),
  invitedAt: timestamp("invited_at").defaultNow().notNull(),
  joinedAt: timestamp("joined_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type CompanyMember = typeof companyMembers.$inferSelect;

// ─── Projects ────────────────────────────────────────────────────
export const projects = mysqlTable("projects", {
  id: serial("id").primaryKey(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  projectCode: varchar("project_code", { length: 50 }).notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  client: varchar("client", { length: 255 }).notNull(),
  consultant: varchar("consultant", { length: 255 }),
  location: varchar("location", { length: 255 }),
  scopeOfWork: text("scope_of_work"),
  projectManager: varchar("project_manager", { length: 255 }),
  startDate: timestamp("start_date"),
  expectedFinishDate: timestamp("expected_finish_date"),
  contractDate: timestamp("contract_date"),
  contractValue: decimal("contract_value", { precision: 15, scale: 2 }).default("0"),
  status: mysqlEnum("status", [
    "tender",
    "awarded",
    "shop_drawings",
    "technical_submittal",
    "fabrication",
    "delivery_to_site",
    "installation",
    "payment",
    "completed",
    "on_hold",
    "cancelled",
  ]).default("tender").notNull(),
  currentStage: mysqlEnum("current_stage", [
    "estimation",
    "contract",
    "technical_submittal",
    "shop_drawings",
    "fabrication",
    "delivery",
    "installation",
    "payments",
    "completed",
  ]).default("estimation").notNull(),
  notes: text("notes"),
  attachments: json("attachments").$type<string[]>(),
  createdById: bigint("created_by_id", { mode: "number", unsigned: true }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Project = typeof projects.$inferSelect;

// ─── Submittals ──────────────────────────────────────────────────
export const submittals = mysqlTable("submittals", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true }).notNull(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  submittalNumber: varchar("submittal_number", { length: 50 }),
  submittedBy: varchar("submitted_by", { length: 255 }),
  submittedDate: timestamp("submitted_date"),
  submittedTo: varchar("submitted_to", { length: 255 }),
  consultantReplyDate: timestamp("consultant_reply_date"),
  replyStatus: mysqlEnum("reply_status", [
    "pending",
    "approved",
    "approved_with_comments",
    "rejected",
    "revise_and_resubmit",
  ]).default("pending").notNull(),
  comments: text("comments"),
  revisionNumber: varchar("revision_number", { length: 20 }).default("0"),
  attachmentLink: text("attachment_link"),
  nextActionRequired: text("next_action_required"),
  responsiblePerson: varchar("responsible_person", { length: 255 }),
  dueDate: timestamp("due_date"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Submittal = typeof submittals.$inferSelect;

// ─── Shop Drawings ───────────────────────────────────────────────
export const shopDrawings = mysqlTable("shop_drawings", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true }).notNull(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  drawingNumber: varchar("drawing_number", { length: 50 }),
  revision: varchar("revision", { length: 20 }).default("0"),
  submittedDate: timestamp("submitted_date"),
  consultantReplyDate: timestamp("consultant_reply_date"),
  approvalStatus: mysqlEnum("approval_status", [
    "pending",
    "approved",
    "approved_with_comments",
    "rejected",
    "revise_and_resubmit",
  ]).default("pending").notNull(),
  approvedQuantity: decimal("approved_quantity", { precision: 12, scale: 2 }).default("0"),
  itemCategory: mysqlEnum("item_category", [
    "curtain_wall",
    "windows",
    "doors",
    "louvers",
    "cladding",
    "handrail",
    "steel_works",
    "stainless_steel",
    "glass_works",
    "skylight",
    "partitions",
    "other",
  ]).default("other").notNull(),
  attachmentLink: text("attachment_link"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type ShopDrawing = typeof shopDrawings.$inferSelect;

// ─── Project Items (Quantities) ──────────────────────────────────
export const projectItems = mysqlTable("project_items", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true }).notNull(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  itemName: varchar("item_name", { length: 255 }).notNull(),
  itemCategory: mysqlEnum("item_category", [
    "curtain_wall",
    "windows",
    "doors",
    "louvers",
    "cladding",
    "handrail",
    "steel_works",
    "stainless_steel",
    "glass_works",
    "skylight",
    "partitions",
    "other",
  ]).default("other").notNull(),
  unit: varchar("unit", { length: 50 }).default("nos").notNull(),
  contractQuantity: decimal("contract_quantity", { precision: 12, scale: 2 }).default("0"),
  shopDrawingApprovedQty: decimal("shop_drawing_approved_qty", { precision: 12, scale: 2 }).default("0"),
  releasedForFabrication: decimal("released_for_fabrication", { precision: 12, scale: 2 }).default("0"),
  fabricatedQuantity: decimal("fabricated_quantity", { precision: 12, scale: 2 }).default("0"),
  deliveredToSite: decimal("delivered_to_site", { precision: 12, scale: 2 }).default("0"),
  receivedBySite: decimal("received_by_site", { precision: 12, scale: 2 }).default("0"),
  installedQuantity: decimal("installed_quantity", { precision: 12, scale: 2 }).default("0"),
  remainingQuantity: decimal("remaining_quantity", { precision: 12, scale: 2 }).default("0"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type ProjectItem = typeof projectItems.$inferSelect;

// ─── Deliveries ──────────────────────────────────────────────────
export const deliveries = mysqlTable("deliveries", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true }).notNull(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  deliveryNoteNumber: varchar("delivery_note_number", { length: 50 }),
  materialDescription: text("material_description").notNull(),
  deliveredQuantity: decimal("delivered_quantity", { precision: 12, scale: 2 }).default("0"),
  receivedQuantity: decimal("received_quantity", { precision: 12, scale: 2 }).default("0"),
  deliveryDate: timestamp("delivery_date"),
  receivedBy: varchar("received_by", { length: 255 }),
  deliveryStatus: mysqlEnum("delivery_status", [
    "pending",
    "in_transit",
    "delivered",
    "received",
    "partial",
    "rejected",
  ]).default("pending").notNull(),
  photos: json("photos").$type<string[]>(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Delivery = typeof deliveries.$inferSelect;

// ─── Installations ───────────────────────────────────────────────
export const installations = mysqlTable("installations", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true }).notNull(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  itemName: varchar("item_name", { length: 255 }).notNull(),
  installedQuantity: decimal("installed_quantity", { precision: 12, scale: 2 }).default("0"),
  installationDate: timestamp("installation_date"),
  areaZone: varchar("area_zone", { length: 255 }),
  floor: varchar("floor", { length: 50 }),
  teamName: varchar("team_name", { length: 255 }),
  siteNotes: text("site_notes"),
  remainingQuantity: decimal("remaining_quantity", { precision: 12, scale: 2 }).default("0"),
  installationPercentage: decimal("installation_percentage", { precision: 5, scale: 2 }).default("0"),
  photos: json("photos").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Installation = typeof installations.$inferSelect;

// ─── Payment Certificates ────────────────────────────────────────
export const paymentCertificates = mysqlTable("payment_certificates", {
  id: serial("id").primaryKey(),
  projectId: bigint("project_id", { mode: "number", unsigned: true }).notNull(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  certificateNumber: varchar("certificate_number", { length: 50 }).notNull(),
  submittedAmount: decimal("submitted_amount", { precision: 15, scale: 2 }).default("0"),
  submissionDate: timestamp("submission_date"),
  approvedAmount: decimal("approved_amount", { precision: 15, scale: 2 }).default("0"),
  approvalDate: timestamp("approval_date"),
  receivedAmount: decimal("received_amount", { precision: 15, scale: 2 }).default("0"),
  paymentReceivedDate: timestamp("payment_received_date"),
  pendingAmount: decimal("pending_amount", { precision: 15, scale: 2 }).default("0"),
  retentionAmount: decimal("retention_amount", { precision: 15, scale: 2 }).default("0"),
  vatAmount: decimal("vat_amount", { precision: 15, scale: 2 }).default("0"),
  totalCollected: decimal("total_collected", { precision: 15, scale: 2 }).default("0"),
  remainingBalance: decimal("remaining_balance", { precision: 15, scale: 2 }).default("0"),
  paymentStatus: mysqlEnum("payment_status", [
    "submitted",
    "under_review",
    "approved",
    "partially_paid",
    "paid",
    "rejected",
  ]).default("submitted").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type PaymentCertificate = typeof paymentCertificates.$inferSelect;

// ─── Activity Logs ───────────────────────────────────────────────
export const activityLogs = mysqlTable("activity_logs", {
  id: serial("id").primaryKey(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }),
  userName: varchar("user_name", { length: 255 }),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entity_type", { length: 50 }).notNull(), // project, submittal, drawing, etc.
  entityId: bigint("entity_id", { mode: "number", unsigned: true }),
  details: text("details"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ActivityLog = typeof activityLogs.$inferSelect;

// ─── Notifications ───────────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  companyId: bigint("company_id", { mode: "number", unsigned: true }).notNull(),
  userId: bigint("user_id", { mode: "number", unsigned: true }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  type: mysqlEnum("type", [
    "submittal_pending",
    "drawing_pending",
    "fabrication_delay",
    "delivery_delay",
    "payment_pending",
    "payment_received",
    "due_date",
    "general",
  ]).default("general").notNull(),
  isRead: boolean("is_read").default(false).notNull(),
  relatedEntityType: varchar("related_entity_type", { length: 50 }),
  relatedEntityId: bigint("related_entity_id", { mode: "number", unsigned: true }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
