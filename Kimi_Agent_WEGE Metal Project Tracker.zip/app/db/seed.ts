import { getDb } from "../api/queries/connection";
import { companies, projects, submittals, shopDrawings, projectItems, deliveries, installations, paymentCertificates } from "./schema";

async function seed() {
  const db = getDb();
  console.log("Seeding demo data...");

  // Create WEGE Metal Company
  const [company] = await db.insert(companies).values({
    name: "WEGE Metal Company",
    slug: "wege-metal-company",
    contactEmail: "admin@wege-metal.com",
    contactPhone: "+971 4 123 4567",
    address: "Dubai Industrial City, Dubai, UAE",
    website: "www.wege-metal.com",
    themeColor: "#D97706",
    isActive: true,
    createdById: 1,
  }).$returningId();

  console.log(`Created company: ${company.id}`);

  // Create demo projects
  const projectData = [
    { projectCode: "PRJ-2024-001", name: "Dubai Marina Towers - Facade Works", client: "EMAAR Properties", consultant: "AECOM Middle East", location: "Dubai Marina, Dubai", scopeOfWork: "Aluminum curtain walls, windows, doors, and cladding for 2 residential towers (G+45 each)", projectManager: "Mohammed Al-Rashid", contractValue: "4850000", status: "installation" as const, currentStage: "installation" as const, notes: "Tower A: 85% installed. Tower B: 60% installed." },
    { projectCode: "PRJ-2024-002", name: "Abu Dhabi Airport Terminal - Louvers", client: "ADAC", consultant: "Dar Al Handasah", location: "Abu Dhabi International Airport", scopeOfWork: "Sun shading louvers, brise soleil, and architectural metal screens", projectManager: "Ahmed Hassan", contractValue: "2100000", status: "fabrication" as const, currentStage: "fabrication" as const, notes: "Material procurement complete. Fabrication at 40%." },
    { projectCode: "PRJ-2024-003", name: "Sharjah Medical Center - Windows & Doors", client: "Sharjah Health Authority", consultant: "WS Atkins", location: "Sharjah University City", scopeOfWork: "Aluminum windows, fire-rated doors, and curtain wall for medical facility", projectManager: "Sara Khalil", contractValue: "1350000", status: "shop_drawings" as const, currentStage: "shop_drawings" as const, notes: "Shop drawings under consultant review." },
    { projectCode: "PRJ-2024-004", name: "Riyadh Business Gate - Steel Works", client: "Saudi Binladin Group", consultant: "Saudi Consulting Services", location: "King Fahd Road, Riyadh", scopeOfWork: "Structural steel, stainless steel handrails, and architectural metalwork", projectManager: "Faisal Omar", contractValue: "3200000", status: "technical_submittal" as const, currentStage: "technical_submittal" as const, notes: "Technical submittals pending consultant approval." },
    { projectCode: "PRJ-2024-005", name: "Doha Festival City - Skylights", client: "Al-Futtaim Group", consultant: "Arup Middle East", location: "Doha, Qatar", scopeOfWork: "Glass skylights, canopies, and ETFE cushions for retail development", projectManager: "Omar Farooq", contractValue: "1800000", status: "delivery_to_site" as const, currentStage: "delivery" as const, notes: "First batch of skylight units delivered. Second batch in transit." },
    { projectCode: "PRJ-2024-006", name: "Kuwait Tower Renovation - Stainless Steel", client: "Kuwait Municipality", consultant: "Khatib & Alami", location: "Kuwait City, Kuwait", scopeOfWork: "Stainless steel cladding replacement and new curtain wall installation", projectManager: "Khalid Mahmoud", contractValue: "4200000", status: "tender" as const, currentStage: "estimation" as const, notes: "Quotation submitted. Awaiting client decision." },
  ];

  for (const p of projectData) {
    const [project] = await db.insert(projects).values({
      ...p,
      companyId: company.id,
      createdById: 1,
    }).$returningId();
    console.log(`Created project: ${p.name} (ID: ${project.id})`);
  }

  // Get project IDs
  const allProjects = await db.select().from(projects).where(
    // @ts-ignore
    projects.companyId.equals ? projects.companyId.equals(company.id) : undefined
  );

  // Create submittals for project 1
  const submittalData = [
    { projectId: 1, companyId: company.id, title: "Aluminum Profile Sample Submission", submittalNumber: "SM-001", submittedBy: "Technical Office", submittedDate: new Date("2024-06-15"), submittedTo: "AECOM", consultantReplyDate: new Date("2024-06-25"), replyStatus: "approved" as const, comments: "Approved with minor comments on anodizing thickness", revisionNumber: "0", responsiblePerson: "Eng. Sami" },
    { projectId: 1, companyId: company.id, title: "Structural Silicone Sealant", submittalNumber: "SM-002", submittedBy: "Technical Office", submittedDate: new Date("2024-06-20"), submittedTo: "AECOM", consultantReplyDate: new Date("2024-07-02"), replyStatus: "approved_with_comments" as const, comments: "Provide additional test certificates", revisionNumber: "1", responsiblePerson: "Eng. Sami" },
    { projectId: 1, companyId: company.id, title: "Glass Panel Specification", submittalNumber: "SM-003", submittedBy: "Technical Office", submittedDate: new Date("2024-07-10"), submittedTo: "AECOM", replyStatus: "pending" as const, comments: "", revisionNumber: "0", responsiblePerson: "Eng. Rania", dueDate: new Date("2024-08-10") },
  ];

  for (const s of submittalData) {
    await db.insert(submittals).values(s);
  }
  console.log("Created submittals");

  // Create shop drawings
  const drawingData = [
    { projectId: 1, companyId: company.id, title: "Curtain Wall - Tower A Levels 1-15", drawingNumber: "SD-001", revision: "A", submittedDate: new Date("2024-07-01"), consultantReplyDate: new Date("2024-07-15"), approvalStatus: "approved" as const, approvedQuantity: "1250", itemCategory: "curtain_wall" as const },
    { projectId: 1, companyId: company.id, title: "Curtain Wall - Tower A Levels 16-30", drawingNumber: "SD-002", revision: "B", submittedDate: new Date("2024-07-20"), replyStatus: "approved_with_comments" as const, approvedQuantity: "1180", itemCategory: "curtain_wall" as const },
    { projectId: 1, companyId: company.id, title: "Windows - Tower B All Levels", drawingNumber: "SD-003", revision: "0", submittedDate: new Date("2024-08-01"), replyStatus: "pending" as const, itemCategory: "windows" as const },
  ];

  for (const d of drawingData) {
    await db.insert(shopDrawings).values(d);
  }
  console.log("Created shop drawings");

  // Create project items
  const itemData = [
    { projectId: 1, companyId: company.id, itemName: "Unitized Curtain Wall - Tower A", itemCategory: "curtain_wall" as const, unit: "sqm", contractQuantity: "8500.00", shopDrawingApprovedQty: "8500.00", releasedForFabrication: "7200.00", fabricatedQuantity: "6500.00", deliveredToSite: "5800.00", receivedBySite: "5800.00", installedQuantity: "5200.00", remainingQuantity: "3300.00" },
    { projectId: 1, companyId: company.id, itemName: "Stick System Curtain Wall - Tower B", itemCategory: "curtain_wall" as const, unit: "sqm", contractQuantity: "6200.00", shopDrawingApprovedQty: "4800.00", releasedForFabrication: "3600.00", fabricatedQuantity: "2800.00", deliveredToSite: "2100.00", receivedBySite: "2100.00", installedQuantity: "1800.00", remainingQuantity: "4400.00" },
    { projectId: 1, companyId: company.id, itemName: "Sliding Windows - Type A", itemCategory: "windows" as const, unit: "nos", contractQuantity: "450.00", shopDrawingApprovedQty: "450.00", releasedForFabrication: "450.00", fabricatedQuantity: "420.00", deliveredToSite: "380.00", receivedBySite: "380.00", installedQuantity: "350.00", remainingQuantity: "100.00" },
    { projectId: 1, companyId: company.id, itemName: "Revolving Door - Main Entrance", itemCategory: "doors" as const, unit: "nos", contractQuantity: "2.00", shopDrawingApprovedQty: "2.00", releasedForFabrication: "2.00", fabricatedQuantity: "2.00", deliveredToSite: "2.00", receivedBySite: "2.00", installedQuantity: "1.00", remainingQuantity: "1.00" },
  ];

  for (const i of itemData) {
    await db.insert(projectItems).values(i);
  }
  console.log("Created project items");

  // Create deliveries
  const deliveryData = [
    { projectId: 1, companyId: company.id, deliveryNoteNumber: "DN-2024-001", materialDescription: "Aluminum Profiles - Mullion 150mm", deliveredQuantity: "240.00", receivedQuantity: "240.00", deliveryDate: new Date("2024-08-15"), receivedBy: "Site Eng. Karim", deliveryStatus: "received" as const },
    { projectId: 1, companyId: company.id, deliveryNoteNumber: "DN-2024-002", materialDescription: "Double Glazed Units - Low-E", deliveredQuantity: "450.00", receivedQuantity: "445.00", deliveryDate: new Date("2024-08-22"), receivedBy: "Site Eng. Karim", deliveryStatus: "partial" as const, notes: "5 units damaged in transit" },
    { projectId: 1, companyId: company.id, deliveryNoteNumber: "DN-2024-003", materialDescription: "Silicone Sealant - Dow Corning 983", deliveredQuantity: "120.00", receivedQuantity: "120.00", deliveryDate: new Date("2024-08-28"), receivedBy: "Site Eng. Karim", deliveryStatus: "received" as const },
  ];

  for (const d of deliveryData) {
    await db.insert(deliveries).values(d);
  }
  console.log("Created deliveries");

  // Create installation records
  const installationData = [
    { projectId: 1, companyId: company.id, itemName: "Unitized Curtain Wall - Tower A", installedQuantity: "5200.00", installationDate: new Date("2024-08-30"), areaZone: "Tower A", floor: "Level 1-35", teamName: "Installation Team A", siteNotes: "Good progress. Weather conditions favorable.", remainingQuantity: "3300.00", installationPercentage: "61.18" },
    { projectId: 1, companyId: company.id, itemName: "Sliding Windows - Type A", installedQuantity: "350.00", installationDate: new Date("2024-08-30"), areaZone: "Tower A", floor: "Level 1-20", teamName: "Window Team", siteNotes: "On schedule", remainingQuantity: "100.00", installationPercentage: "77.78" },
  ];

  for (const i of installationData) {
    await db.insert(installations).values(i);
  }
  console.log("Created installation records");

  // Create payment certificates
  const paymentData = [
    { projectId: 1, companyId: company.id, certificateNumber: "PC-001", submittedAmount: "850000.00", submissionDate: new Date("2024-07-31"), approvedAmount: "820000.00", approvalDate: new Date("2024-08-10"), receivedAmount: "820000.00", paymentReceivedDate: new Date("2024-08-20"), pendingAmount: "0.00", retentionAmount: "41000.00", totalCollected: "820000.00", remainingBalance: "4030000.00", paymentStatus: "paid" as const },
    { projectId: 1, companyId: company.id, certificateNumber: "PC-002", submittedAmount: "1250000.00", submissionDate: new Date("2024-08-31"), approvedAmount: "1200000.00", approvalDate: new Date("2024-09-10"), receivedAmount: "600000.00", paymentReceivedDate: new Date("2024-09-15"), pendingAmount: "600000.00", retentionAmount: "60000.00", totalCollected: "1420000.00", remainingBalance: "3430000.00", paymentStatus: "partially_paid" as const },
    { projectId: 1, companyId: company.id, certificateNumber: "PC-003", submittedAmount: "950000.00", submissionDate: new Date("2024-09-30"), replyStatus: "submitted" as const, pendingAmount: "950000.00", totalCollected: "1420000.00", remainingBalance: "3430000.00", paymentStatus: "submitted" as const },
  ];

  for (const p of paymentData) {
    await db.insert(paymentCertificates).values(p as any);
  }
  console.log("Created payment certificates");

  console.log("Seed complete! Demo data created for WEGE Metal Company.");
}

seed().catch(console.error);
